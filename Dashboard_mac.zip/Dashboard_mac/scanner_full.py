"""
=============================================================================
SCANNER TÍN HIỆU MUA CỔ PHIẾU — PHIÊN BẢN TỐI ƯU
Pocket Pivot / Breakout / Pre-Break / BottomFish / BottomBreakP / MA_Cross
Tích hợp: VNDirect Batch + VNDirect + Telegram + Chart mplfinance + Dashboard
+ HEATMAP BOT (lệnh /h hoặc /heatmap)
+ CHỈ SỐ: VNINDEX, VN30 (lệnh /VNINDEX, /VN30, /c VNINDEX ...)
+ CHART 15 PHÚT: gửi kèm tín hiệu, on-demand, và khi nhấn nút /s
+ PHÂN QUYỀN: VIP (toàn quyền) / Free (tối đa 20 slot đồng thời, TTL 30 phút)
+ DASHBOARD WEB: http://VPS_IP:8888 — Tín hiệu + Heatmap + Scanner Chart
=============================================================================
"""
from __future__ import annotations

# =============================================================================
# BƯỚC 1: IMPORT
# =============================================================================
from __future__ import annotations
import pandas as pd
import numpy as np
import requests
import time
import mplfinance as mpf
import sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import logging
import os
import gc
import re
import tempfile
from io import BytesIO
from datetime import datetime, date, timezone
import pytz
import json
import threading
import math
from PIL import Image, ImageDraw, ImageFont
from dashboard_server import (
    start_dashboard,
    get_active_price_alert_rules,
    record_price_alert_event,
    warm_market_health_cache,
    invalidate_rs_cache,
    warm_rs_cache,
    load_persisted_caches,
    TS_POOL_CONFIG,
    HMAP_COLS_CONFIG,
    _rs_score_cache,
)

class DailyRotatingStdout:
    def __init__(self, filename="scanner.log", max_lines=2500):
        self.filename, self.max_lines, self.terminal = filename, max_lines, sys.stdout
        self.line_count = 0
        try:
            is_dup = (os.fstat(sys.stdout.fileno()).st_ino == os.stat(filename).st_ino)
        except Exception:
            is_dup = False
        self.file = None if is_dup else open(filename, "a", encoding="utf-8")
        if self.file and os.path.exists(filename):
            with open(filename, "r", encoding="utf-8", errors="ignore") as f:
                self.line_count = sum(1 for _ in f)

    def write(self, message):
        self.terminal.write(message)
        if self.file:
            self.file.write(message)
            if '\n' in message:
                self.line_count += message.count('\n')
                if self.line_count > self.max_lines + 500:
                    self.file.close()
                    with open(self.filename, "r", encoding="utf-8", errors="ignore") as f:
                        lines = f.readlines()
                    with open(self.filename, "w", encoding="utf-8") as f:
                        f.writelines(lines[-self.max_lines:])
                    self.file = open(self.filename, "a", encoding="utf-8")
                    self.line_count = self.max_lines

    def flush(self):
        self.terminal.flush()
        if self.file:
            self.file.flush()

sys.stdout = DailyRotatingStdout()

logging.getLogger("matplotlib.font_manager").setLevel(logging.ERROR)

# =============================================================================
# BƯỚC 2: CẤU HÌNH
# =============================================================================
TELEGRAM_BOT_TOKEN  = os.environ.get('TELEGRAM_BOT_TOKEN')
TELEGRAM_CHAT_ID    = os.environ.get('TELEGRAM_CHAT_ID')
MY_PERSONAL_CHAT_ID = os.environ.get('MY_PERSONAL_CHAT_ID')
ENABLE_TELEGRAM     = os.environ.get('ENABLE_TELEGRAM', 'false').lower() in ('true', '1', 'yes')

SCAN_INTERVAL_SEC  = 60
CACHE_CHECK_INTERVAL_SEC = 1800   # nhịp tự dò/sửa history_cache NGOÀI giờ giao dịch — độc lập với SCAN_INTERVAL_SEC
TZ_VN              = pytz.timezone('Asia/Ho_Chi_Minh')

sys.setswitchinterval(0.001)  # nhả GIL thường xuyên hơn (mặc định 5ms), giảm độ trễ chart trên dashboard khi scanner đang tính toán

# =============================================================================
# BƯỚC 2A: PHÂN QUYỀN VIP / FREE SLOT
# =============================================================================
VIP_CHAT_IDS = {
    str(TELEGRAM_CHAT_ID),
    str(MY_PERSONAL_CHAT_ID),
    '1207484510',
}

FREE_CHAT_LIMIT = 10
SESSION_TTL     = 1800
free_sessions: dict = {}
free_lock = threading.Lock()

def is_vip(chat_id: str) -> bool:
    return chat_id in VIP_CHAT_IDS

def is_allowed(chat_id: str) -> tuple[bool, str]:
    if is_vip(chat_id):
        return True, 'vip'
    now = time.time()
    with free_lock:
        expired = [k for k, v in free_sessions.items() if now - v > SESSION_TTL]
        for k in expired:
            del free_sessions[k]
            print(f"  🔄 Free slot hết hạn: {k} → giải phóng ({len(free_sessions)}/{FREE_CHAT_LIMIT})")
        if chat_id in free_sessions:
            free_sessions[chat_id] = now
            return True, 'free_existing'
        if len(free_sessions) < FREE_CHAT_LIMIT:
            free_sessions[chat_id] = now
            print(f"  ✅ Free slot mới: {chat_id} ({len(free_sessions)}/{FREE_CHAT_LIMIT})")
            return True, 'free_new'
        print(f"  🚫 Free slot đầy: {chat_id} bị từ chối ({FREE_CHAT_LIMIT}/{FREE_CHAT_LIMIT})")
        return False, 'full'

# =============================================================================
# BƯỚC 2B: DANH SÁCH CHỈ SỐ HỖ TRỢ
# =============================================================================
INDEX_SYMBOL_MAP = {
    'VNINDEX':   'VNINDEX',
    'VN30':      'VN30',
    'HNX':       'HNX',
    'HNXINDEX':  'HNXINDEX',
    'UPCOM':     'UPCOM',
    'VN100':     'VN100',
    'VN30F1M':   'VN30F1M',
}
INDEX_SYMBOLS = set(INDEX_SYMBOL_MAP.keys())

# =============================================================================
# BƯỚC 2C: CẤU HÌNH HEATMAP
# =============================================================================
_HEATMAP_NEED_SYMBOLS = list(
    {s for col in HMAP_COLS_CONFIG for g in col["groups"] for s in g["syms"]}
    | set(TS_POOL_CONFIG)
)

HMAP_POS_COLORS = [
    (235,248,238), (231,247,234), (225,245,228), (220,243,224),
    (215,242,220), (205,238,211), (195,235,200), (186,232,193),
    (178,228,186), (169,224,178), (160,220,170), (154,218,165),
    (148,216,160),
]
HMAP_NEG_COLORS = [
    (255,232,225), (255,224,216), (255,220,210), (254,212,204),
    (253,205,197), (252,195,186), (250,185,175), (248,176,167),
    (246,168,160), (244,163,156), (243,158,152), (242,154,149),
    (240,150,145),
]
HMAP_CEIL_COLOR = (250,170,225)
HMAP_REF_COLOR  = (245,245,200)
HMAP_FLOOR_COLOR = (175,250,255)

def _hmap_cell_color(pct):
    if pct >= 6.5:
        return HMAP_CEIL_COLOR
    if pct >= 0.05:
        return HMAP_POS_COLORS[min(len(HMAP_POS_COLORS) - 1, math.floor(pct * 2))]
    if pct > -0.05:
        return HMAP_REF_COLOR
    if pct >= -6.5:
        return HMAP_NEG_COLORS[min(len(HMAP_NEG_COLORS) - 1, math.floor(abs(pct) * 2))]
    return HMAP_FLOOR_COLOR

def _hmap_fg(bg):
    lum = 0.299*bg[0] + 0.587*bg[1] + 0.114*bg[2]
    return (30,30,30) if lum > 160 else (15,15,15)

HMAP_CELL_W      = 162
HMAP_CELL_H      = 26
HMAP_COL_GAP     = 4
HMAP_COL_W       = HMAP_CELL_W + HMAP_COL_GAP
HMAP_MARGIN      = 5
HMAP_TOP_BAR     = 32
HMAP_RADIUS      = 5
HMAP_BG          = (252,252,252)
HMAP_HDR_FILL    = (220,228,250)
HMAP_HDR_OUTLINE = (160,180,230)
HMAP_HDR_FG      = (25,55,150)
HMAP_SECTOR_FG_P = (30,140,40)
HMAP_SECTOR_FG_N = (190,30,30)
HMAP_SECTOR_FG_0 = (120,120,30)

def _hmap_rounded_rect(draw, x0, y0, x1, y1, r, fill, outline=None, lw=1):
    draw.rectangle([x0+r, y0, x1-r, y1], fill=fill)
    draw.rectangle([x0, y0+r, x1, y1-r], fill=fill)
    draw.pieslice([x0, y0, x0+2*r, y0+2*r], 180, 270, fill=fill)
    draw.pieslice([x1-2*r, y0, x1, y0+2*r], 270, 360, fill=fill)
    draw.pieslice([x0, y1-2*r, x0+2*r, y1], 90,  180, fill=fill)
    draw.pieslice([x1-2*r, y1-2*r, x1, y1], 0,    90, fill=fill)
    if outline:
        draw.arc([x0, y0, x0+2*r, y0+2*r], 180, 270, fill=outline, width=lw)
        draw.arc([x1-2*r, y0, x1, y0+2*r], 270, 360, fill=outline, width=lw)
        draw.arc([x0, y1-2*r, x0+2*r, y1], 90,  180, fill=outline, width=lw)
        draw.arc([x1-2*r, y1-2*r, x1, y1], 0,    90, fill=outline, width=lw)
        draw.line([x0+r, y0, x1-r, y0], fill=outline, width=lw)
        draw.line([x0+r, y1, x1-r, y1], fill=outline, width=lw)
        draw.line([x0, y0+r, x0, y1-r], fill=outline, width=lw)
        draw.line([x1, y0+r, x1, y1-r], fill=outline, width=lw)

def _hmap_load_fonts():
    # Load DejaVu Sans từ matplotlib hoặc font hệ thống
    try:
        _mpl_font_dir = os.path.join(matplotlib.get_data_path(), "fonts", "ttf")
    except Exception:
        _mpl_font_dir = ""
    bold_paths = [
        os.path.join(_mpl_font_dir, "DejaVuSans-Bold.ttf"),
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "C:/Windows/Fonts/arialbd.ttf",
    ]
    reg_paths = [
        os.path.join(_mpl_font_dir, "DejaVuSans.ttf"),
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        "C:/Windows/Fonts/arial.ttf",
    ]
    bold = next((p for p in bold_paths if os.path.exists(p)), None)
    reg  = next((p for p in reg_paths  if os.path.exists(p)), None)
    try:
        f_title  = ImageFont.truetype(bold, 13)
        f_hdr    = ImageFont.truetype(bold, 10)
        f_sym    = ImageFont.truetype(bold, 10)
        f_data   = ImageFont.truetype(reg or bold, 9)
        f_sector = ImageFont.truetype(bold, 11)
        return f_title, f_hdr, f_sym, f_data, f_sector
    except Exception:
        d = ImageFont.load_default()
        return d, d, d, d, d

def _hmap_draw_stock_cell(draw, x, y, sym, price, pct, f_sym, f_data):
    bg = _hmap_cell_color(pct)
    fg = _hmap_fg(bg)
    x1, y1 = x + HMAP_CELL_W - 1, y + HMAP_CELL_H - 2
    _hmap_rounded_rect(draw, x, y, x1, y1, HMAP_RADIUS, fill=bg, outline=(200,205,215), lw=1)
    w1 = int(HMAP_CELL_W * 0.35)
    w2 = int(HMAP_CELL_W * 0.30)
    w3 = HMAP_CELL_W - w1 - w2
    ty = y + (HMAP_CELL_H - 2) // 2 - 5

    def dc(txt, fnt, bx, bw):
        bb = draw.textbbox((0, 0), txt, font=fnt)
        draw.text((bx + (bw - (bb[2] - bb[0])) // 2, ty), txt, font=fnt, fill=fg)

    dc(sym,                                                    f_sym,  x,       w1)
    dc(f"{price:,.2f}" if price < 100 else f"{price:,.0f}",   f_data, x + w1,  w2)
    dc(f"{pct:+.1f}%",                                        f_data, x+w1+w2, w3)

def _hmap_draw_group_header(draw, x, y, name, avg_pct, f_hdr, f_sector):
    x1, y1 = x + HMAP_CELL_W - 1, y + HMAP_CELL_H - 2
    _hmap_rounded_rect(draw, x, y, x1, y1, HMAP_RADIUS,
                       fill=HMAP_HDR_FILL, outline=HMAP_HDR_OUTLINE, lw=1)
    w1 = int(HMAP_CELL_W * 0.65)
    w2 = HMAP_CELL_W - w1
    ty = y + (HMAP_CELL_H - 2) // 2 - 5

    def dc(txt, fnt, bx, bw, color):
        bb = draw.textbbox((0, 0), txt, font=fnt)
        draw.text((bx + (bw - (bb[2] - bb[0])) // 2, ty), txt, font=fnt, fill=color)

    dc(name, f_hdr, x, w1, HMAP_HDR_FG)
    fg_s = HMAP_SECTOR_FG_P if avg_pct > 0 else (HMAP_SECTOR_FG_N if avg_pct < 0 else HMAP_SECTOR_FG_0)
    dc(f"{avg_pct:+.1f}%", f_sector, x + w1, w2, fg_s)

def _hmap_avg_pct(syms, data):
    vals = [data[s]["pct"] for s in syms if s in data]
    return round(sum(vals) / len(vals), 1) if vals else 0.0

def _hmap_col_height(groups):
    h = HMAP_TOP_BAR + HMAP_MARGIN
    for g in groups:
        h += (1 + len(g["syms"])) * HMAP_CELL_H
    return h + HMAP_MARGIN

def _parse_trade_date(it: dict) -> str:
    raw = str(it.get('tradingDate') or it.get('date') or '').strip()
    if len(raw) == 8 and raw.isdigit():
        return f"{raw[:4]}-{raw[4:6]}-{raw[6:8]}"
    if len(raw) >= 10 and '-' in raw[:10]:
        return raw[:10]
    now_dt = datetime.now(TZ_VN)
    now_date = now_dt.date()
    now_time = int(now_dt.strftime("%H%M%S"))
    return _expected_last_session(now_date, now_time).strftime('%Y-%m-%d')

def _extract_heatmap_fallback(df):
    ref_p, close, vol = float(df.iloc[-2]['close']), float(df.iloc[-1]['close']), float(df.iloc[-1]['volume'])
    pct = round((close - ref_p) / ref_p * 100, 2) if ref_p > 0 else 0.0
    return {
        "price": close, "pct": 0.0 if not math.isfinite(pct) else pct,
        "total_value": round(close * vol * 1000, 0),
        "open": float(df.iloc[-1].get('open', close)),
        "high": float(df.iloc[-1].get('high', close)),
        "low": float(df.iloc[-1].get('low', close)), "volume": vol,
        "date": df.index[-1].strftime('%Y-%m-%d')
    }

def fetch_heatmap_data() -> tuple:
    need = _HEATMAP_NEED_SYMBOLS
    ts_log = datetime.now(TZ_VN).strftime('%H:%M:%S')
    result = {}
    try:
        items = _fetch_priceboard_batch(need)
        for it in items:
            sym = str(it.get('stockSymbol') or '').upper().strip()
            if not sym:
                continue
            matched, ref_p = float(it.get('matchedPrice') or 0), float(it.get('refPrice') or 0)
            if matched > 0:
                close = matched
                pct = round((close - ref_p) / ref_p * 100, 2) if ref_p > 0 else 0.0
                o = float(it.get('openPrice') or close)
                hi = max(float(it.get('highest') or close), o, close)
                lo = min(float(it.get('lowest') or close), o, close)
                vol = float(it.get('nmTotalTradedQty') or 0)
                tot_val = float(it.get('nmTotalTradedValue') or 0)
                result[sym] = {
                    "price": close, "pct": 0.0 if not math.isfinite(pct) else pct, "total_value": tot_val,
                    "open": o, "high": hi, "low": lo, "volume": vol, "date": _parse_trade_date(it)
                }
            else:
                with cache_lock:
                    df = history_cache.get(sym)
                if df is not None and len(df) >= 2:
                    result[sym] = _extract_heatmap_fallback(df)
    except Exception as e:
        print(f"  [{ts_log}] ❌ Bảng giá SSI lỗi: {e}")

    if not result:
        with cache_lock:
            for sym in need:
                df = history_cache.get(sym)
                if df is not None and len(df) >= 2:
                    result[sym] = _extract_heatmap_fallback(df)
        if result:
            print(f"  [{ts_log}] 🗺 SSI Priceboard không khả dụng → Fallback lấy {len(result)}/{len(need)} mã từ Cache VNDirect")

    with cache_lock:
        for idx_sym in ("VNINDEX", "VN30"):
            df = history_cache.get(idx_sym)
            if df is not None and len(df) >= 2:
                result[idx_sym] = _extract_heatmap_fallback(df)

    return result, datetime.now(TZ_VN).strftime("%H:%M  %d/%m/%Y") if result else ""


def fetch_extra_quotes(syms: list) -> dict:
    syms = [s for s in dict.fromkeys(s.strip().upper() for s in syms) if s]
    if not syms:
        return {}
    result = {}
    try:
        items = _fetch_priceboard_batch(syms)
        for it in items:
            sym = it.get('stockSymbol')
            if not sym:
                continue
            matched, ref_p = float(it.get('matchedPrice') or 0), float(it.get('refPrice') or 0)
            close = matched if matched > 0 else ref_p
            pct = round((close - ref_p) / ref_p * 100, 2) if ref_p > 0 else 0.0
            o = float(it.get('openPrice') or close)
            result[sym.upper().strip()] = {
                "price": close, "pct": pct, "open": o,
                "high": max(float(it.get('highest') or close), o, close),
                "low": min(float(it.get('lowest') or close), o, close),
                "volume": float(it.get('nmTotalTradedQty') or 0), "date": _parse_trade_date(it)
            }
    except Exception as e:
        print(f"  ❌ fetch_extra_quotes lỗi: {e}")

    if not result:
        with cache_lock:
            for sym in syms:
                df = history_cache.get(sym)
                if df is not None and len(df) >= 2:
                    ref_p, close = float(df.iloc[-2]['close']), float(df.iloc[-1]['close'])
                    pct = round((close - ref_p) / ref_p * 100, 2) if ref_p > 0 else 0.0
                    result[sym] = {
                        "price": close, "pct": 0.0 if not math.isfinite(pct) else pct,
                        "open": float(df.iloc[-1].get('open', close)),
                        "high": float(df.iloc[-1].get('high', close)),
                        "low": float(df.iloc[-1].get('low', close)),
                        "volume": float(df.iloc[-1]['volume']),
                        "date": df.index[-1].strftime('%Y-%m-%d')
                    }
    return result


def build_heatmap_image(data: dict, timestamp: str) -> str:
    f_title, f_hdr, f_sym, f_data, f_sector = _hmap_load_fonts()

    max_rows   = max(sum(len(g["syms"]) for g in c["groups"]) for c in HMAP_COLS_CONFIG)
    ts_display = sorted(
        [s for s in TS_POOL_CONFIG if s in data],
        key=lambda s: data[s]["pct"], reverse=True
    )[:max_rows]

    def srt(syms):
        return sorted(syms, key=lambda s: data.get(s, {}).get("pct", 0), reverse=True)

    col0     = {"col": 0, "groups": [{"name": "TRADING STOCKS", "syms": ts_display}]}
    all_cols = [col0] + [{"col": idx + 1, **cd} for idx, cd in enumerate(HMAP_COLS_CONFIG)]

    all_sorted = []
    for cd in all_cols:
        all_sorted.append([{"name": g["name"], "syms": srt(g["syms"])} for g in cd["groups"]])

    IMG_W = len(all_cols) * HMAP_COL_W + HMAP_MARGIN * 2
    IMG_H = max(_hmap_col_height(gs) for gs in all_sorted)

    img  = Image.new("RGB", (IMG_W, IMG_H), HMAP_BG)
    draw = ImageDraw.Draw(img)

    _hmap_rounded_rect(draw, 0, 0, IMG_W - 1, HMAP_TOP_BAR, 0,
                       fill=(238,242,255), outline=(180,195,235), lw=1)
    draw.text((HMAP_MARGIN + 5, 9), f"MARKET MAP   {timestamp}",
              font=f_title, fill=(15,35,115))
    legend = "  Ma | Gia | %Gia"
    bb = draw.textbbox((0, 0), legend, font=f_data)
    draw.text((IMG_W - (bb[2] - bb[0]) - 8, 11), legend, font=f_data, fill=(100,110,140))

    for idx, cd in enumerate(all_cols):
        cx = cd["col"] * HMAP_COL_W + HMAP_MARGIN
        y  = HMAP_TOP_BAR + HMAP_MARGIN
        for g in all_sorted[idx]:
            avg = _hmap_avg_pct(g["syms"], data)
            _hmap_draw_group_header(draw, cx, y, g["name"], avg, f_hdr, f_sector)
            y += HMAP_CELL_H
            for sym in g["syms"]:
                info = data.get(sym, {})
                _hmap_draw_stock_cell(draw, cx, y, sym,
                                      info.get("price", 0.0), info.get("pct", 0.0),
                                      f_sym, f_data)
                y += HMAP_CELL_H

    draw.rectangle([0, 0, IMG_W - 1, IMG_H - 1], outline=(200,210,230), width=1)

    fd, path = tempfile.mkstemp(suffix='_heatmap.png')
    os.close(fd)
    img.save(path, "PNG", optimize=True)
    ts_log = datetime.now(TZ_VN).strftime('%H:%M:%S')
    print(f"  [{ts_log}] 🗺  Heatmap: ảnh {IMG_W}x{IMG_H}px → {path}")
    return path


def handle_heatmap_command(chat_id):
    url_msg   = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    url_photo = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendPhoto"
    url_act   = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendChatAction"
    try:
        requests.post(url_act, data={"chat_id": chat_id, "action": "upload_photo"}, timeout=5)
        requests.post(url_msg, data={
            "chat_id": chat_id,
            "text": "🗺 Đang tải dữ liệu heatmap, vui lòng chờ 5–10 giây..."
        })
        data, ts_str = fetch_heatmap_data()
        if not data:
            requests.post(url_msg, data={"chat_id": chat_id,
                                         "text": "❌ Không lấy được dữ liệu heatmap. Thử lại sau."})
            return
        path = build_heatmap_image(data, ts_str)
        with open(path, "rb") as f:
            r = requests.post(url_photo, data={
                "chat_id":    chat_id,
                "caption":    f"<b>MARKET MAP</b>  {ts_str}",
                "parse_mode": "HTML",
            }, files={"photo": f}, timeout=60)
        if os.path.exists(path): os.remove(path)
        ts_log = datetime.now(TZ_VN).strftime('%H:%M:%S')
        print(f"  [{ts_log}] 🗺  Heatmap gửi {'OK' if r.status_code == 200 else 'THẤT BẠI'} → chat_id={chat_id}")
    except Exception as e:
        ts_log = datetime.now(TZ_VN).strftime('%H:%M:%S')
        print(f"  [{ts_log}] ❌ handle_heatmap_command lỗi: {e}")
        requests.post(url_msg, data={"chat_id": chat_id, "text": f"❌ Lỗi heatmap: {e}"})

# =============================================================================
# BƯỚC 3: HÀM BỔ TRỢ (TELEGRAM & WEEKLY DATA)
# =============================================================================
def build_weekly_df(df_daily):
    df_w = df_daily[['open','high','low','close','volume']].resample('W-FRI').agg({
        'open':'first','high':'max','low':'min','close':'last','volume':'sum',
    }).dropna()
    return compute_indicators(df_w)

def build_monthly_df(df_daily):
    df_m = df_daily[['open','high','low','close','volume']].resample('ME').agg({
        'open':'first','high':'max','low':'min','close':'last','volume':'sum',
    }).dropna()
    return compute_indicators(df_m)

def send_telegram_signal(msg, image_paths=None, image_path=None, notify_text=None):
    if not ENABLE_TELEGRAM:
        return
    if image_path and not image_paths:
        image_paths = [image_path]

    url_photo = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendPhoto"
    url_album = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMediaGroup"
    url_msg   = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"

    try:
        if notify_text:
            requests.post(url_msg, data={
                'chat_id': TELEGRAM_CHAT_ID, 'text': notify_text, 'parse_mode': 'HTML'
            })

        if image_paths and len(image_paths) == 1:
            with open(image_paths[0], 'rb') as f:
                requests.post(url_photo, data={
                    'chat_id': TELEGRAM_CHAT_ID, 'caption': msg or '',
                    'parse_mode': 'HTML', 'disable_notification': True,
                }, files={'photo': f})
            print(f"  ✅ Đã gửi chart: {image_paths[0]}")

        elif image_paths and len(image_paths) >= 2:
            files, media = {}, []
            for i, path in enumerate(image_paths):
                key = f"photo{i}"; files[key] = open(path, 'rb')
                item = {"type": "photo", "media": f"attach://{key}"}
                if i == 0 and msg:
                    item["caption"] = msg; item["parse_mode"] = "HTML"
                media.append(item)
            try:
                requests.post(url_album, data={
                    'chat_id': TELEGRAM_CHAT_ID, 'media': json.dumps(media),
                    'disable_notification': True,
                }, files=files)
                print(f"  ✅ Đã gửi album: {image_paths[0]}")
            finally:
                for fh in files.values(): fh.close()

        if image_paths:
            for path in image_paths:
                if os.path.exists(path): os.remove(path)

    except Exception as e:
        print(f"  ❌ Lỗi gửi Telegram: {e}")

# =============================================================================
# BƯỚC 4: DANH SÁCH MÃ QUÉT
# =============================================================================
SIGNAL_SCAN_SYMBOLS = [
    'AAA', 'ACB', 'ANV', 'BAF', 'BFC', 'BID', 'BSI', 'BSR', 'BVH', 'BWE', 'C4G', 'CII', 'CRE', 'CTD', 'CTG',
    'CTI', 'CTR', 'CTS', 'DBC', 'DCM', 'DGW', 'DIG', 'DPG', 'DPM', 'DXG', 'FCN', 'FPT', 'FRT', 'FTS', 'G36',
    'GAS', 'GEG', 'GEX', 'GMD', 'GVR', 'HAG', 'HAH', 'HAX', 'HBC', 'HCM', 'HDB', 'HDC', 'HDG', 'HHV', 'HNG',
    'HPG', 'HSG', 'HTN', 'IDC', 'IJC', 'KBC', 'KDH', 'KSB', 'LPB', 'MBB', 'MBS', 'MIG', 'MSB', 'MSN', 'MWG',
    'NKG', 'NLG', 'NTL', 'NVL', 'OIL', 'ORS', 'PC1', 'PET', 'PLC', 'PLX', 'PNJ', 'POW', 'PVD', 'PVS', 'PVT',
    'REE', 'SBT', 'SCR', 'SHB', 'SHS', 'SSI', 'STB', 'SZC', 'TCB', 'TIG', 'TNG', 'TPB', 'VCB', 'VCI', 'VGC',
    'VGT', 'VHC', 'VHM', 'VIB', 'VIC', 'VJC', 'VND', 'VNM', 'VPB', 'VRE',
]
heatmap_symbols = {
    s
    for col in HMAP_COLS_CONFIG
    for group in col["groups"]
    for s in group["syms"]
}
cache_symbol_set = set(SIGNAL_SCAN_SYMBOLS) | set(TS_POOL_CONFIG) | heatmap_symbols
_HEATMAP_NEED_SYMBOLS = list(set(_HEATMAP_NEED_SYMBOLS) | set(SIGNAL_SCAN_SYMBOLS))
symbols_to_scan = list(dict.fromkeys(SIGNAL_SCAN_SYMBOLS))
symbols_to_rs = list(dict.fromkeys(cache_symbol_set))
symbols_to_cache = list(dict.fromkeys(symbols_to_rs + ["VNINDEX", "VN30"]))

# =============================================================================
# BƯỚC 5: HÀM TÍNH CHỈ BÁO
# =============================================================================
def ref(series, n):  return series.shift(n)
def hhv(series, n):  return series.rolling(n).max()
def llv(series, n):  return series.rolling(n).min()

def cross_above(s1, s2):
    return (s1 >= s2) & (s1.shift(1) < s2.shift(1))

def afl_cross(s1, s2):
    if not isinstance(s2, pd.Series):
        s2 = pd.Series(s2, index=s1.index)
    return ((s1 > s2) & (s1.shift(1) <= s2.shift(1))).astype(bool)

def compute_indicators(df):
    df = df.copy()
    for n in [2,3,5,10,15,20,30,50,100,200]:
        df[f'MA{n}']  = df['close'].rolling(n).mean()
    for n in [10,20,30,50,100,200]:
        df[f'EMA{n}'] = df['close'].ewm(span=n, adjust=False).mean()
    for n in [2,3,5,10,15,20,30,50]:
        df[f'VMA{n}'] = df['volume'].rolling(n).mean()

    delta    = df['close'].diff()
    gain     = delta.clip(lower=0)
    loss     = (-delta).clip(lower=0)
    avg_gain = gain.ewm(alpha=1/14, min_periods=14, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1/14, min_periods=14, adjust=False).mean()
    rs       = avg_gain / avg_loss.replace(0, np.nan)
    df['RSI14'] = 100 - (100 / (1 + rs))

    exp12 = df['close'].ewm(span=12, adjust=False).mean()
    exp26 = df['close'].ewm(span=26, adjust=False).mean()
    df['MACD']             = exp12 - exp26
    df['MACD_Signal']      = df['MACD'].ewm(span=9, adjust=False).mean()
    df['MACD_Hist_origin'] = df['MACD'] - df['MACD_Signal']
    df['MACD_Hist']        = df['MACD_Hist_origin'] * 3
    df['A']                = df['close'].pct_change()
    return df


# =============================================================================
# BƯỚC 5A1: VPA FLAG — tô màu Volume (port rút gọn từ AFL "Signal Generation" +
# "Volume ADD"). Với NHÁNH XANH DƯƠNG (cảnh báo suy yếu/phân phối), đã port:
#   - Điều kiện cổng ngoài cùng: upmajor>=0 AND upminor>=0
#   - Nhánh 1 ("biến A"): volume bất thường kèm giá không tăng
#   - Nhánh 2 (VSA): upThrustBar OR upThrustBarTrue OR topRevBar
#     (upThrustBarTrue KHÔNG phải tập con của upThrustBar — nó không đòi
#     upminor>0, chỉ cần upmajor>0 — nên bắt thêm được tín hiệu mà
#     upThrustBar bỏ sót, đã đối chiếu kỹ với AFL gốc và port đủ cả 2)
# CHƯA port: Nhánh 3 (~36 pattern nến bearish kèm điều kiện giá ở đỉnh 120
# phiên) — chi phí port lớn, giá trị tăng thêm nhỏ vì đã có điều kiện phụ rất
# chặt (đỉnh 120 phiên + volume bất thường) mới kích hoạt. Toàn bộ ~65 pattern
# nến (cả bullish lẫn bearish) trong AFL gốc vẫn KHÔNG port, theo đúng thống
# nhất từ đầu.
#
# AFL gốc gọi thẳng AmiBroker built-in RWIHi(min,max)/RWILo(min,max)/RWI(min,max).
# AmiBroker tính RWI bằng ATR(p) ở mẫu số; ATR() của AmiBroker dùng Wilder
# smoothing, không phải MA đơn giản của True Range. Vì vậy phần port dưới đây tự
# tính Wilder ATR trước khi quét p từ min→max để giảm lệch phân loại blue/cyan
# quanh ngưỡng upmajor/upminor.
# =============================================================================
def _true_range(df):
    prev_close = df['close'].shift(1)
    return pd.concat([
        df['high'] - df['low'],
        (df['high'] - prev_close).abs(),
        (df['low']  - prev_close).abs(),
    ], axis=1, sort=False).max(axis=1)

def _wilder_atr(tr, period):
    """ATR(period) theo Wilder/AmiBroker: seed bằng SMA(period), sau đó recursive."""
    period = int(period)
    if period <= 0:
        raise ValueError("period must be positive")
    arr = pd.to_numeric(tr, errors='coerce').to_numpy(dtype=float)
    out = np.full(len(arr), np.nan, dtype=float)
    valid = np.isfinite(arr)
    if len(arr) < period or not valid[:period].all():
        return pd.Series(out, index=tr.index)
    out[period - 1] = arr[:period].mean()
    for i in range(period, len(arr)):
        if np.isfinite(arr[i]) and np.isfinite(out[i - 1]):
            out[i] = (out[i - 1] * (period - 1) + arr[i]) / period
    return pd.Series(out, index=tr.index)

def _rwi_hi_lo(df, pmin, pmax, tr=None):
    """RWIHi/RWILo: với mỗi p trong [pmin, pmax], dùng ATR(p) Wilder giống AmiBroker."""
    if tr is None:
        tr = _true_range(df)
    hi_max = pd.Series(0.0, index=df.index)
    lo_max = pd.Series(0.0, index=df.index)
    for p in range(pmin, pmax + 1):
        denom = _wilder_atr(tr, p) * math.sqrt(p)
        hi = ((df['high'] - df['low'].shift(p)) / denom).fillna(0)
        lo = ((df['high'].shift(p) - df['low']) / denom).fillna(0)
        hi_max = np.maximum(hi_max, hi)
        lo_max = np.maximum(lo_max, lo)
    return hi_max, lo_max

def calc_vpa_flag(df, rwi_short=(2, 8), rwi_long=(10, 40), min_bars=140):
    """
    Trả về Series int8 cùng index với df:
      0 = trung tính  → giữ màu xanh/đỏ theo close/open như cũ
      1 = cảnh báo suy yếu / phân phối → tô xanh dương
          gate(upmajor>=0 AND upminor>=0) AND
          (Nhánh1-biến A OR upThrustBar OR upThrustBarTrue OR topRevBar)
      2 = tín hiệu tích lũy mạnh (stopVolume OR revUpThrust) → tô tím

    df cần tối thiểu các cột: open, high, low, close, volume.
    Nếu dữ liệu chưa đủ dài (RWI dài hạn cần ~40 phiên lùi + rolling(80) cho
    avg_spread) thì trả về toàn 0 để tránh tín hiệu nhiễu/rác.
    """
    if df is None or len(df) < min_bars:
        return pd.Series(0, index=(df.index if df is not None else []), dtype='int8')

    h, l, c, v = df['high'], df['low'], df['close'], df['volume']
    tr = _true_range(df)

    hi_st, _        = _rwi_hi_lo(df, *rwi_short, tr=tr)   # Ground — dùng cho upimd
    hi_lt, lo_lt     = _rwi_hi_lo(df, *rwi_long,  tr=tr)   # j2/lo_lt — dùng cho upmajor/upminor

    j       = hi_lt - lo_lt                 # RWI dài hạn có dấu (theo cross(j,1)/cross(j,-1) trong AFL)
    upmajor = np.select([j > 1, j < -1], [1, -1], default=0)
    upminor = np.where(hi_lt > 1, 1, -1)
    upimd   = np.where(hi_st > 1, 1, 0)
    gate_not_downtrend = (upmajor >= 0) & (upminor >= 0)   # điều kiện cổng bọc ngoài toàn nhánh xanh dương

    spread     = h - l
    avg_spread = spread.rolling(80).mean()
    wide_range_bar = spread > 1.5 * avg_spread

    maV5, maV20, maV50 = v.rolling(5).mean(), v.rolling(20).mean(), v.rolling(50).mean()
    vol_avg = v.rolling(30).mean()   # = maV30 trong AFL
    up_bar   = c > c.shift(1)
    down_bar = c < c.shift(1)

    # Nhánh 1 (biến "A" trong AFL): giá không tăng, đi kèm volume bất thường
    # theo 1 trong 3 kiểu — báo hiệu lực bán/phân phối đang âm thầm diễn ra.
    dv = v / v.shift(1)
    nhanh1 = (c <= c.shift(1)) & (
        ((dv > 1.06) & ((v > vol_avg) | (v > maV50) | (v > maV20)))
        | ((v > maV5) & (v > 1.2 * maV20) & (v > 1.2 * vol_avg) & (v > 1.2 * maV50))
        | ((v > v.shift(1)) & (v > maV5) & (v > maV20) & (v > vol_avg) & (v > maV50))
    )

    close_pos = np.select(
        [c <= spread * 0.2 + l, c <= spread * 0.4 + l, c <= spread * 0.6 + l, c <= spread * 0.8 + l],
        [1, 2, 3, 4], default=5,
    )
    vol_pos = np.select(
        [v > vol_avg * 2, v > vol_avg * 1.3, v > vol_avg],
        [1, 2, 3],
        default=np.where((v < vol_avg) & (v > vol_avg * 0.7), 4, 5),
    )
    up_close   = c >= spread * 0.7 + l
    down_close = c <= spread * 0.3 + l
    mid_close  = (c > spread * 0.3 + l) & (c < spread * 0.7 + l)

    up_bar_prev1, down_bar_prev1     = up_bar.shift(1, fill_value=False), down_bar.shift(1, fill_value=False)
    wide_bar_prev1                   = wide_range_bar.shift(1, fill_value=False)
    down_close_prev1                 = down_close.shift(1, fill_value=False)

    up_thrust_bar = (
        wide_range_bar & np.isin(close_pos, [1, 2]) & (upminor > 0) &
        (h > h.shift(1)) & ((upimd > 0) | (upmajor > 0)) & (vol_pos < 4)
    )
    up_thrust_bar_true = (
        wide_range_bar & (close_pos == 1) & (upmajor > 0) &
        (h > h.shift(1)) & (vol_pos < 4)
    )
    top_rev_bar = (
        (v.shift(1) > vol_avg) & up_bar_prev1 & wide_bar_prev1 &
        down_bar & down_close & wide_range_bar & (upmajor > 0) & (h == h.rolling(10).max())
    )
    stop_volume = (
        (l == l.rolling(5).min()) & (up_close | mid_close) & (v > 1.5 * vol_avg) & (upmajor < 0)
    )
    rev_up_thrust = (
        (upmajor < 0) & up_bar & up_close & (v > v.shift(1)) & (v > vol_avg) &
        wide_range_bar & down_bar_prev1 & down_close_prev1 & (upminor < 0)
    )

    flag = pd.Series(0, index=df.index, dtype='int8')
    blue_signal = gate_not_downtrend & (nhanh1 | up_thrust_bar | up_thrust_bar_true | top_rev_bar)
    # Gate tím: AFL gốc bọc (upmajor<0 AND upminor<0) ngoài (stopVolume OR revUpThrust)
    # trước khi tô "Super Up Color" — thiếu vế upminor<0 khiến stop_volume tô tím cả khi
    # upminor>=0 (dương tính giả so với bản gốc).
    purple_gate = (upmajor < 0) & (upminor < 0)
    flag[blue_signal.fillna(False).astype(bool)]                                   = 1
    flag[(purple_gate & (stop_volume | rev_up_thrust)).fillna(False).astype(bool)] = 2   # ưu tiên tích lũy nếu trùng cả 2 (hiếm)
    return flag


# =============================================================================
# BƯỚC 5A2: MARKET HEALTH / FEAR-GREED INDEX
# =============================================================================
def _mh_finite_float(value, default=None):
    try:
        value = float(value)
        return value if np.isfinite(value) else default
    except Exception:
        return default


def _mh_score_band(score: float) -> dict:
    if score >= 80:
        return {"key": "euphoria", "label": "Hưng phấn", "tone": "purple"}
    if score >= 60:
        return {"key": "positive", "label": "Lạc quan", "tone": "green"}
    if score >= 40:
        return {"key": "neutral", "label": "Trung tính", "tone": "yellow"}
    if score >= 20:
        return {"key": "negative", "label": "Bi quan", "tone": "red"}
    return {"key": "fear", "label": "Sợ hãi", "tone": "cyan"}


def _mh_percentile_score(series: pd.Series, window: int = 60) -> pd.Series:
    series = pd.to_numeric(series, errors="coerce")

    def _rank(x):
        x = pd.Series(x).dropna()
        if len(x) < 20:
            return np.nan
        return 100.0 * (x <= x.iloc[-1]).mean()

    return series.rolling(window, min_periods=20).apply(_rank, raw=False).clip(0, 100)


def _mh_last_streak(values, pred) -> int:
    n = 0
    for v in reversed(list(values)):
        if pred(v):
            n += 1
        else:
            break
    return n


def _mh_component_phrase(key: str, value) -> str:
    """
    Chuyển điểm số 0-100 của từng thành phần HEALTH thành một câu mô tả bằng
    ngôn ngữ thường, dùng để đưa vào phần NHẬN ĐỊNH thay cho việc hiển thị số
    dạng "X/100" trên thanh ngang — người đọc không cần hiểu ý nghĩa thang điểm
    nội bộ, chỉ cần đọc câu là hiểu ngay tình trạng thị trường.
    """
    v = _mh_finite_float(value)
    if v is None:
        return ""
    if key == "momentum":
        if v >= 80: return "Đà thị trường đang tăng rất mạnh so với giai đoạn gần đây"
        if v >= 60: return "Đà thị trường nghiêng lạc quan"
        if v >= 40: return "Đà thị trường trung tính, chưa có xu hướng rõ ràng"
        if v >= 20: return "Đà thị trường đang suy yếu"
        return "Đà thị trường rất yếu, thấp hơn hẳn xu hướng gần đây"
    if key == "volatility":
        if v >= 80: return "Biến động giá đang rất thấp, thị trường ổn định"
        if v >= 60: return "Biến động giá ở mức thấp"
        if v >= 40: return "Biến động giá ở mức bình thường"
        if v >= 20: return "Biến động giá đang cao hơn bình thường"
        return "Biến động giá đang rất cao, thị trường dao động mạnh bất thường"
    if key == "breadth":
        if v >= 70: return "Phần lớn cổ phiếu trong rổ vẫn giữ vững xu hướng tăng"
        if v >= 50: return "Đa số cổ phiếu còn giữ xu hướng tăng"
        if v >= 30: return "Số cổ phiếu giữ xu hướng tăng và giảm khá cân bằng"
        if v >= 15: return "Phần lớn cổ phiếu đã gãy xu hướng tăng"
        return "Hầu hết cổ phiếu trong rổ đã mất xu hướng tăng"
    if key == "new_high_low":
        if v >= 80: return "Số mã phá đỉnh 52 tuần (trong phiên) áp đảo, không nhiều mã phá đáy"
        if v >= 60: return "Số mã phá đỉnh (trong phiên) nhỉnh hơn số mã phá đáy"
        if v >= 40: return "Chưa có làn sóng phá đỉnh hay phá đáy đáng chú ý"
        if v >= 20: return "Số mã phá đáy 52 tuần (trong phiên) nhỉnh hơn số mã phá đỉnh"
        return "Có mã phá đáy 52 tuần trong khi không có mã nào phá đỉnh"
    if key == "volume":
        if v >= 80: return "Dòng tiền đổ vào rất mạnh, nhiều mã tăng kèm khối lượng đột biến"
        if v >= 60: return "Dòng tiền nghiêng về mua chủ động"
        if v >= 40: return "Dòng tiền theo khối lượng chưa rõ xu hướng"
        if v >= 20: return "Dòng tiền nghiêng về bán, xuất hiện phiên giảm kèm khối lượng lớn"
        return "Áp lực bán rất mạnh, nhiều mã giảm sâu kèm khối lượng đột biến"
    if key == "rsi":
        # RSI dùng ngưỡng quy ước riêng (70/30) thay vì thang 20-40-60-80 chung,
        # vì RSI vốn đã là chỉ báo có ý nghĩa chuẩn hoá quen thuộc với người đọc.
        if v >= 70: return "RSI trung vị đã vào vùng quá mua"
        if v >= 55: return "RSI trung vị nghiêng lạc quan"
        if v >= 45: return "RSI trung vị ở vùng trung tính"
        if v >= 30: return "RSI trung vị nghiêng bi quan"
        return "RSI trung vị đã vào vùng quá bán"
    return ""


def compute_market_health_index(limit: int = 120) -> dict:
    """
    Chỉ số HEALTH/Fear-Greed dùng hoàn toàn dữ liệu đang có trong history_cache.
    Mỗi phiên được chấm 0-100 từ momentum proxy, volatility, breadth, new high/low,
    RSI trung vị và volume stress của rổ HEATMAP/TRADING.
    """
    # NGƯỠNG ĐỘ DÀI TỐI THIỂU: đồng bộ với build_history_cache() (dòng ~848) —
    # nơi coi 1 mã là "đã cache hợp lệ" khi có >= 60 phiên. Trước đây HEALTH tự
    # đòi >= 80 phiên, khiến mọi mã có 60-79 phiên (mã mới niêm yết, mã bị giới
    # hạn lịch sử từ nguồn dữ liệu...) bị coi là "đã cache" ở MỌI nơi khác trong
    # hệ thống nhưng lại bị âm thầm loại khỏi HEALTH — dễ gây hiểu lầm "cache đủ
    # rồi mà vẫn báo thiếu". Với 60 phiên, các chỉ báo HEALTH đang dùng (MA50,
    # RSI14, VMA20, rolling 252 với min_periods=60) vẫn tính đủ giá trị hợp lệ ở
    # phiên gần nhất nên hạ ngưỡng là an toàn, không làm giảm chất lượng tính.
    MH_MIN_ROWS = 60
    with cache_lock:
        # Không .copy() ở đây: chỉ giữ reference để thoát lock nhanh. An toàn vì
        # history_cache chỉ bị thay bằng cách gán lại key (history_cache[sym] = df_moi)
        # ở nơi khác trong file, không có chỗ nào sửa in-place lên DataFrame đang tồn tại
        # — nên object df đang giữ reference ở đây sẽ không bị đổi ngầm sau khi thoát lock.
        raw_cache = {
            sym: df
            for sym, df in history_cache.items()
            if sym in cache_symbol_set and df is not None and len(df) >= MH_MIN_ROWS
        }

    prepared = {}
    for sym, df in raw_cache.items():
        try:
            cols = [c for c in ["open", "high", "low", "close", "volume"] if c in df.columns]
            if "close" not in cols:
                continue
            d = df[cols].copy().sort_index()
            if "volume" not in d.columns:
                d["volume"] = 0
            d.index = pd.to_datetime(d.index).normalize()
            d = d[~d.index.duplicated(keep="last")]
            # Check độ dài NGAY SAU dedup (trước compute_indicators): dedup là bước
            # duy nhất có thể làm giảm số dòng ở đây, nên lọc sớm để khỏi tốn công
            # tính ~20 cột indicator (MA/EMA/RSI/MACD) cho các mã vừa bị loại.
            if len(d) < MH_MIN_ROWS:
                continue
            d = compute_indicators(d)
            prepared[sym] = d
        except Exception:
            continue

    if len(prepared) < 20:
        return {
            "ok": False,
            "error": "not_enough_cache",
            "message": f"Chưa đủ cache để tính Mrk Health ({len(prepared)} mã hợp lệ).",
            "history": [],
            "components": [],
        }

    close_df = pd.concat({sym: d["close"] for sym, d in prepared.items()}, axis=1, sort=False).sort_index()
    close_df = close_df.dropna(how="all").tail(360)
    returns = close_df.pct_change(fill_method=None)
    eq_ret = returns.mean(axis=1, skipna=True).fillna(0)
    market_proxy = (1 + eq_ret).cumprod() * 100
    momentum_raw = (market_proxy / market_proxy.rolling(20, min_periods=12).mean() - 1) * 100
    volatility_raw = -eq_ret.rolling(10, min_periods=5).std() * np.sqrt(252) * 100
    momentum_score = _mh_percentile_score(momentum_raw)
    volatility_score = _mh_percentile_score(volatility_raw)

    above_ma50, rsi14, new_high, new_low, vol_push, decline_today, hoang_loan, ban_thao = {}, {}, {}, {}, {}, {}, {}, {}
    for sym, d in prepared.items():
        above_ma50[sym] = (d["close"] > d["MA50"]).astype(float)
        rsi14[sym] = d["RSI14"]
        new_high[sym] = (d["close"] >= d["close"].rolling(252, min_periods=60).max()).astype(float)
        new_low[sym] = (d["close"] <= d["close"].rolling(252, min_periods=60).min()).astype(float)
        pct = d["close"].pct_change() * 100
        decline_today[sym] = (pct < 0).astype(float)
        v_ratio = d["volume"] / d["VMA20"].replace(0, np.nan)
        excite = ((pct >= 2.5) & (v_ratio >= 1.5)).astype(float)
        panic = ((pct <= -2.5) & (v_ratio >= 1.5)).astype(float)
        vol_push[sym] = excite - panic
        hoang_loan[sym] = ((pct <= -2.5) & (pct > -4) & (v_ratio >= 1.3)).astype(float)
        ban_thao[sym] = ((pct <= -4) & (v_ratio >= 1.3)).astype(float)

    dates = close_df.index[-max(limit, 30):]
    breadth_s = pd.concat(above_ma50, axis=1, sort=False).reindex(dates).mean(axis=1, skipna=True) * 100
    decline_s = pd.concat(decline_today, axis=1, sort=False).reindex(dates).mean(axis=1, skipna=True) * 100
    hoang_loan_s = pd.concat(hoang_loan, axis=1, sort=False).reindex(dates).mean(axis=1, skipna=True) * 100
    ban_thao_s = pd.concat(ban_thao, axis=1, sort=False).reindex(dates).mean(axis=1, skipna=True) * 100
    rsi_s = pd.concat(rsi14, axis=1, sort=False).reindex(dates).median(axis=1, skipna=True).clip(0, 100)
    nh_s = pd.concat(new_high, axis=1, sort=False).reindex(dates).sum(axis=1, skipna=True)
    nl_s = pd.concat(new_low, axis=1, sort=False).reindex(dates).sum(axis=1, skipna=True)
    denom = (nh_s + nl_s).replace(0, np.nan)
    newhl_s = (50 + 50 * ((nh_s - nl_s) / denom)).fillna(50).clip(0, 100)
    vol_push_s = (50 + 50 * pd.concat(vol_push, axis=1, sort=False).reindex(dates).mean(axis=1, skipna=True)).clip(0, 100)

    component_series = {
        "momentum": momentum_score.reindex(dates),
        "volatility": volatility_score.reindex(dates),
        "breadth": breadth_s,
        "new_high_low": newhl_s,
        "rsi": rsi_s,
        "volume": vol_push_s,
    }
    score_df = pd.DataFrame(component_series)
    score = score_df.mean(axis=1, skipna=True).clip(0, 100)

    usable = score.dropna()
    if usable.empty:
        return {
            "ok": False,
            "error": "not_enough_history",
            "message": "Cache chưa đủ lịch sử để tính Mrk Health.",
            "history": [],
            "components": [],
        }

    # VNINDEX không nằm trong cache_symbol_set (rổ dùng để tính HEALTH), nên phải
    # tự đảm bảo có dữ liệu — dùng lại đúng cơ chế ensure-on-demand mà CHART tab
    # đang dùng khi người dùng xem chart VNINDEX, tránh viết thêm luồng fetch riêng.
    try:
        ensure_symbol_live_in_cache("VNINDEX")
    except Exception:
        pass
    with cache_lock:
        _vni_df = history_cache.get("VNINDEX")
    vni_close = None
    if _vni_df is not None and not _vni_df.empty and "close" in _vni_df.columns:
        vni_close = _vni_df["close"].copy()
        vni_close.index = pd.to_datetime(vni_close.index).normalize()
        vni_close = vni_close[~vni_close.index.duplicated(keep="last")]

    last_dates = list(usable.tail(limit).index)
    history = []
    for dt in last_dates:
        entry = {
            "date": pd.Timestamp(dt).strftime("%Y-%m-%d"),
            "score": round(float(score.loc[dt]), 1),
        }
        if vni_close is not None:
            v = vni_close.get(dt)
            entry["vnindex"] = round(float(v), 2) if v is not None and pd.notna(v) else None
        history.append(entry)

    cur_dt = last_dates[-1]
    cur_score = float(score.loc[cur_dt])
    prev_score = float(score.loc[last_dates[-2]]) if len(last_dates) >= 2 else cur_score
    current_components = {
        k: _mh_finite_float(v.loc[cur_dt])
        for k, v in component_series.items()
    }
    component_labels = {
        "momentum": "Đà thị trường",
        "volatility": "Biến động",
        "breadth": "Độ rộng",
        "new_high_low": "Đỉnh/đáy 52 tuần",
        "rsi": "RSI trung vị",
        "volume": "Dòng tiền/volume",
    }
    components = [
        {
            "key": k,
            "label": component_labels[k],
            "score": round(v, 1) if v is not None else None,
        }
        for k, v in current_components.items()
    ]

    recent_scores = [x["score"] for x in history[-10:]]
    high_streak = _mh_last_streak(recent_scores, lambda x: x >= 75)
    low_streak = _mh_last_streak(recent_scores, lambda x: x <= 25)
    rising_3 = len(history) >= 4 and history[-1]["score"] > history[-4]["score"]
    falling_3 = len(history) >= 4 and history[-1]["score"] < history[-4]["score"]

    breadth_now = current_components.get("breadth") or 0
    decline_now = _mh_finite_float(decline_s.loc[cur_dt]) if cur_dt in decline_s.index else None
    hoang_loan_now = _mh_finite_float(hoang_loan_s.loc[cur_dt]) if cur_dt in hoang_loan_s.index else None
    ban_thao_now = _mh_finite_float(ban_thao_s.loc[cur_dt]) if cur_dt in ban_thao_s.index else None

    band = _mh_score_band(cur_score)
    delta = cur_score - prev_score

    # Xu hướng ngắn hạn dùng chung cho các tag "đảo chiều"/"phân phối" bên dưới:
    # reversing_top/recovering_bottom = đã XÁC NHẬN đổi chiều (falling_3/rising_3
    # hoặc delta cùng dấu). Tách bạch với "chưa đổi chiều" để tag cảnh báo sớm
    # (Dấu hiệu phân phối) và tag xác nhận đảo chiều (Điều chỉnh từ đỉnh) không
    # lặp lại cùng một ý nghĩa ở 2 thời điểm khác nhau.
    reversing_top = falling_3 or delta < 0
    recovering_bottom = rising_3 or delta > 0
    max_recent_10 = max(recent_scores)
    min_recent_10 = min(recent_scores)

    tags = []
    if cur_score >= 90:
        tags.append("Cực kỳ hưng phấn")
    if cur_score <= 10:
        tags.append("Cực kỳ sợ hãi")
    # "Dấu hiệu phân phối": cảnh báo SỚM — breadth đã yếu trong khi streak điểm cao
    # vẫn đang giữ, giá CHƯA xác nhận giảm (not reversing_top). Cố ý không giới hạn
    # trần cur_score nên có thể trùng với "Cực kỳ hưng phấn" (kịch bản "blow-off
    # top": giá vẫn tăng rất mạnh nhưng độ rộng đã co hẹp) — đây là chủ đích, không
    # phải lỗi.
    if high_streak >= 3 and breadth_now < 55 and not reversing_top:
        tags.append("Dấu hiệu phân phối")
    # "Điều chỉnh từ đỉnh": gộp 2 tag cũ ("Rủi ro tạo đỉnh" + "Hạ nhiệt từ hưng
    # phấn") vì cùng mô tả 1 quá trình (giá đảo chiều sau giai đoạn hưng phấn),
    # chỉ khác lát cắt thời điểm đo:
    #   - Nhánh A: điểm vẫn ≥75 (đang trong streak cao) nhưng đã bắt đầu giảm.
    #   - Nhánh B: điểm đã rơi xuống band Lạc quan (60-80, hở 2 đầu để không đụng
    #     "Tích lũy cân bằng" ở mốc 60 và không đụng "Cực kỳ hưng phấn" ở mốc 90)
    #     nhưng gần đây (10 phiên) từng đạt Hưng phấn (≥80).
    # Nhánh A không giới hạn trần điểm nên vẫn có thể trùng "Cực kỳ hưng phấn" —
    # chủ đích, giữ nguyên như "Dấu hiệu phân phối" ở trên.
    if (high_streak >= 3 and falling_3) or (
        60 < cur_score < 80 and max_recent_10 >= 80 and reversing_top
    ):
        tags.append("Điều chỉnh từ đỉnh")
    # "Phục hồi từ đáy": đối xứng với "Điều chỉnh từ đỉnh", gộp "Tín hiệu dò đáy" +
    # "Hồi phục từ sợ hãi". Không có tag "cảnh báo sớm" đối xứng với "Dấu hiệu phân
    # phối" ở phía đáy — có chủ đích, vì breadth cải thiện sớm ở vùng đáy không
    # mang tính cảnh báo rủi ro như breadth suy yếu sớm ở vùng đỉnh.
    if (low_streak >= 3 and rising_3) or (
        20 <= cur_score < 40 and min_recent_10 <= 20 and recovering_bottom
    ):
        tags.append("Phục hồi từ đáy")
    # "Hoảng loạn" / "Bán tháo" là sự kiện CẤP TÍNH trong 1 phiên (giảm sâu + volume
    # xác nhận), không lệ thuộc band/xu hướng điểm HEALTH nhiều phiên trước đó — nên
    # có thể xảy ra ngay cả khi thị trường đang uptrend (VD phiên phân phối đỉnh, RSI
    # vẫn >80 là bình thường). Vì vậy KHÔNG dùng cur_score/breadth_now(MA50)/rsi_now ở
    # đây, chỉ dùng % mã thỏa biên độ giảm + volume đột biến ≥1.3x TB 20 phiên trong
    # chính phiên đó. Hai tag loại trừ lẫn nhau ở cấp độ từng mã (2,5%-4% vs ≥4%),
    # nhưng vẫn có thể cùng xuất hiện nếu cả 2 nhóm mã đều đủ % ngưỡng diện rộng.
    MH_PANIC_PCT = 60  # ngưỡng % mã thỏa điều kiện để coi là diện rộng, áp dụng cho cả 2 tag
    if (hoang_loan_now or 0) >= MH_PANIC_PCT:
        tags.append("Hoảng loạn")
    if (ban_thao_now or 0) >= MH_PANIC_PCT:
        tags.append("Bán tháo")
    if 45 <= cur_score <= 60 and abs(delta) <= 4 and 40 <= breadth_now <= 60:
        tags.append("Tích lũy cân bằng")
    if not tags:
        tags.append("Theo dõi xu hướng")

    summary = (
        f"Mrk Health hiện ở vùng {band['label']} ({cur_score:.1f}/100), "
        f"{'tăng' if delta >= 0 else 'giảm'} {abs(delta):.1f} điểm so với phiên trước."
    )
    factors = [
        p for p in (
            _mh_component_phrase("momentum", current_components.get("momentum")),
            _mh_component_phrase("volatility", current_components.get("volatility")),
            _mh_component_phrase("breadth", current_components.get("breadth")),
            _mh_component_phrase("new_high_low", current_components.get("new_high_low")),
            _mh_component_phrase("volume", current_components.get("volume")),
            _mh_component_phrase("rsi", current_components.get("rsi")),
        ) if p
    ]
    factors = [f"{p}." for p in factors]
    if decline_now is not None:
        factors.append(f"Trong phiên hôm nay có khoảng {decline_now:.0f}% cổ phiếu trong rổ giảm giá.")
    has_euphoria = "Cực kỳ hưng phấn" in tags
    has_fear = "Cực kỳ sợ hãi" in tags
    has_correction = "Điều chỉnh từ đỉnh" in tags
    has_distribution = "Dấu hiệu phân phối" in tags
    has_recovery = "Phục hồi từ đáy" in tags

    if has_euphoria and has_correction:
        conclusion = "Kết luận: Chỉ số đang ở vùng cực kỳ hưng phấn (≥90/100) và đã bắt đầu chững/quay đầu — rủi ro đảo chiều ngắn hạn cao; ưu tiên chốt lời/giảm tỷ trọng ở nhóm đã tăng nóng, tránh mua đuổi."
    elif has_euphoria and has_distribution:
        conclusion = "Kết luận: Chỉ số đang ở vùng cực kỳ hưng phấn (≥90/100) nhưng độ rộng thị trường không theo kịp đà tăng giá — dấu hiệu phân phối sớm giữa lúc tăng nóng; rủi ro đảo chiều ngắn hạn cao, ưu tiên chốt lời/giảm tỷ trọng, tránh mua đuổi."
    elif has_euphoria:
        conclusion = "Kết luận: Chỉ số đang ở vùng cực kỳ hưng phấn (≥90/100) — thị trường tăng nóng, rủi ro đảo chiều ngắn hạn gia tăng; ưu tiên chốt lời/giảm tỷ trọng ở nhóm đã tăng mạnh, hạn chế mua đuổi."
    elif has_fear and has_recovery:
        conclusion = "Kết luận: Chỉ số đang ở vùng cực kỳ sợ hãi (≤10/100) và đã có dấu hiệu hồi phục — tâm lý bán tháo đang dịu bớt, có thể là vùng dò đáy tiềm năng nhưng vẫn cần thêm phiên xác nhận độ rộng/RSI trước khi giải ngân, tránh bắt đáy sớm."
    elif has_fear:
        conclusion = "Kết luận: Chỉ số đang ở vùng cực kỳ sợ hãi (≤10/100) — tâm lý bán là chủ đạo, thường là vùng dò đáy tiềm năng, nhưng cần chờ xác nhận độ rộng/RSI cải thiện trước khi giải ngân, tránh bắt đáy sớm."
    elif has_correction:
        conclusion = "Kết luận: Chỉ số đang điều chỉnh từ vùng hưng phấn/lạc quan — đà tăng đã bớt nóng và bắt đầu suy yếu; ưu tiên chốt lời một phần ở nhóm tăng mạnh trước đó, hạn chế mua đuổi."
    elif has_distribution:
        conclusion = "Kết luận: Điểm Mrk Health vẫn ở vùng cao nhưng độ rộng thị trường đang thu hẹp — dấu hiệu phân phối sớm, nền tăng đang mỏng dần dù giá chưa xác nhận giảm; nên bắt đầu thận trọng, hạn chế mua mới, chưa cần bán vội nếu điểm Mrk Health chưa giảm rõ."
    elif has_recovery:
        conclusion = "Kết luận: Chỉ số đang phục hồi từ vùng sợ hãi/bi quan — lực bán đã suy yếu và tâm lý đang cải thiện; theo dõi quá trình tạo đáy, nhưng chưa nên coi là xác nhận đảo chiều nếu độ rộng chưa cải thiện rõ."
    elif "Tích lũy cân bằng" in tags:
        conclusion = "Kết luận: Thị trường nghiêng về tích lũy/cân bằng; chưa có xác nhận đỉnh hoặc đáy rõ ràng."
    else:
        conclusion = "Kết luận: Chưa có tín hiệu cực đoan đủ mạnh theo band điểm Mrk Health để kết luận đỉnh hoặc đáy; tiếp tục theo dõi breadth và volume."
    # Hoảng loạn/Bán tháo là sự kiện CẤP TÍNH trong phiên, có thể trùng với BẤT KỲ tag/
    # band nào ở trên (kể cả giữa uptrend) — thay vì lồng vào từng nhánh phía trên (dễ
    # gây rối, khó bảo trì), luôn thêm 1 câu nhận xét ĐỘC LẬP ở cuối, tách bạch rõ ràng.
    if "Bán tháo" in tags:
        pct_str = f"~{ban_thao_now:.0f}%" if ban_thao_now is not None else "nhiều"
        conclusion += f" Xuất hiện dấu hiệu bán tháo diện rộng ({pct_str} số mã giảm ≥4% kèm volume ≥1,3 lần TB20) — thận trọng khi giao dịch."
    elif "Hoảng loạn" in tags:
        pct_str = f"~{hoang_loan_now:.0f}%" if hoang_loan_now is not None else "nhiều"
        conclusion += f" Xuất hiện dấu hiệu hoảng loạn diện rộng ({pct_str} số mã giảm 2,5%-4% kèm volume ≥1,3 lần TB20) — thận trọng khi giao dịch, tránh phản ứng thái quá."

    return {
        "ok": True,
        "as_of": pd.Timestamp(cur_dt).strftime("%Y-%m-%d"),
        "updated_at": datetime.now(TZ_VN).strftime("%Y-%m-%d %H:%M:%S"),
        "score": round(cur_score, 1),
        "delta": round(delta, 1),
        "band": band,
        "tags": tags,
        "history": history,
        "components": components,
        "vnindex_available": vni_close is not None,
        "analysis": {
            "summary": summary,
            "factors": factors,
            "conclusion": conclusion,
        },
        "meta": {
            "symbols": len(prepared),
            "lookback_sessions": len(last_dates),
            "source": "history_cache",
        },
    }

# =============================================================================
# BƯỚC 5B: NẠP DỮ LIỆU & CACHE LỊCH SỬ (VNDIRECT ĐA LUỒNG & BATCH)
# =============================================================================
history_cache: dict = {}
cache_lock          = threading.Lock()
last_bar_update: dict = {}   # {symbol: timestamp} - dùng chung cho CẢ scan cycle lẫn chart on-demand
BAR_UPDATE_TTL_SEC = 60

_vndirect_session = requests.Session()
_vndirect_session.headers.update({
    "User-Agent": "Mozilla/5.0",
    "Accept": "application/json,*/*",
    "Referer": "https://dstock.vndirect.com.vn/",
})

try:
    from curl_cffi import requests as cffi_requests
    _ssi_session = cffi_requests.Session(impersonate="chrome120")
except ImportError:
    _ssi_session = requests.Session()

_ssi_session.headers.update({
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json, text/plain, */*",
    "Content-Type": "application/json",
    "Origin": "https://iboard.ssi.com.vn",
    "Referer": "https://iboard.ssi.com.vn/",
})

def _fetch_history_candles(symbol: str, limit: int, resolution: str = "D"):
    symbol = symbol.upper().strip()
    to_ts = int(time.time())
    if resolution == "15":
        from_ts = to_ts - int(limit * 3600 * 24 / 20)
    else:
        from_ts = to_ts - int(limit * 1.6 + 30) * 86400
    url = f"https://dchart-api.vndirect.com.vn/dchart/history?resolution={resolution}&symbol={symbol}&from={from_ts}&to={to_ts}"
    res = _vndirect_session.get(url, timeout=10)
    if res.status_code != 200: return None
    data = res.json()
    if not data or data.get("s") != "ok" or not data.get("t"): return None
    times, opens, highs = data.get("t", []), data.get("o", []), data.get("h", [])
    lows, closes, vols = data.get("l", []), data.get("c", []), data.get("v", [])
    bars = []
    for i in range(len(times)):
        try:
            o, h, l, c, v = float(opens[i]), float(highs[i]), float(lows[i]), float(closes[i]), float(vols[i])
            if all(math.isfinite(x) and x > 0 for x in (o, h, l, c)):
                dt = datetime.fromtimestamp(times[i] + 25200, timezone.utc).replace(tzinfo=None)
                bars.append({"time": dt, "open": o, "high": h, "low": l, "close": c, "volume": max(0.0, v)})
        except: pass
    if not bars: return None
    df = pd.DataFrame(bars)
    df.set_index('time', inplace=True)
    return df

def _fetch_priceboard_batch(symbols: list[str]) -> list[dict]:
    """Lấy bảng giá real-time từ SSI iBoard API (định dạng chuẩn, có sẵn giá Open)."""
    if not symbols:
        return []
    url = "https://iboard-query.ssi.com.vn/stock/multiple"
    results = []
    for i in range(0, len(symbols), 100):
        if i > 0:
            time.sleep(0.15)
        chunk = [s.upper().strip() for s in symbols[i:i + 100] if s.strip()]
        if not chunk:
            continue
        try:
            res = _ssi_session.post(url, json={"stocks": chunk}, timeout=5)
            if res.status_code == 200:
                raw_data = res.json().get("data", [])
                if isinstance(raw_data, list):
                    for it in raw_data:
                        if not isinstance(it, dict):
                            continue
                        sym = str(it.get("stockSymbol") or "").upper().strip()
                        if not sym:
                            continue
                        
                        ref_p = float(it.get('refPrice') or 0.0) / 1000.0
                        ceil_p = float(it.get('ceiling') or 0.0) / 1000.0
                        floor_p = float(it.get('floor') or 0.0) / 1000.0
                        high_p = float(it.get('highest') or 0.0) / 1000.0
                        low_p = float(it.get('lowest') or 0.0) / 1000.0
                        match_p = float(it.get('matchedPrice') or 0.0) / 1000.0
                        open_p = float(it.get('openPrice') or 0.0) / 1000.0
                        project_open = float(it.get('expectedMatchedPrice') or 0.0) / 1000.0
                        
                        if high_p <= 0: high_p = ref_p
                        if low_p <= 0: low_p = ref_p
                        
                        display_price = match_p if match_p > 0 else (project_open if project_open > 0 else ref_p)
                        open_price = open_p if open_p > 0 else display_price
                        
                        total_vol = float(it.get('nmTotalTradedQty') or it.get('stockVol') or 0.0)
                        total_val = float(it.get('nmTotalTradedValue') or 0.0)
                        
                        results.append({
                            'stockSymbol': sym,
                            'refPrice': ref_p,
                            'floor': floor_p,
                            'ceiling': ceil_p,
                            'highest': high_p,
                            'lowest': low_p,
                            'matchedPrice': display_price,
                            'projectOpen': project_open,
                            'stockVol': total_vol,
                            'nmTotalTradedQty': total_vol,
                            'nmTotalTradedValue': total_val,
                            'openPrice': open_price,
                            'tradingDate': it.get('tradingDate') or it.get('date') or ''
                        })
        except Exception:
            pass
    return results


def load_history_for_symbol(symbol: str):
    time.sleep(0.08)
    for attempt in range(3):
        try:
            df = _fetch_history_candles(symbol, limit=5000)
            if df is None or len(df) < 60: return None
            df['vpa_flag'] = calc_vpa_flag(df)
            return df
        except Exception as e:
            if attempt < 2: time.sleep(0.5)
            else: print(f"    ❌ Load history {symbol}: {e}")
    return None

def build_history_cache(symbols: list, current_date: date):
    ts = datetime.now(TZ_VN).strftime('%H:%M:%S')
    print(f"\n📦 [{ts}] Nạp cache lịch sử {len(symbols)} mã [DChart đa luồng]...")
    new_history = {}
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = {executor.submit(load_history_for_symbol, s): s for s in symbols}
        for fut in futures:
            s = futures[fut]
            try:
                df = fut.result()
                if df is not None and len(df) >= 60:
                    new_history[s] = df
            except Exception:
                pass
    with cache_lock:
        history_cache.clear()
        history_cache.update(new_history)
    gc.collect()
    invalidate_rs_cache()
    warm_rs_cache()
    warm_market_health_cache()
    export_market_bundle(history_cache, cache_lock)
    ts = datetime.now(TZ_VN).strftime('%H:%M:%S')
    print(f"✅ [{ts}] Hoàn tất nạp cache: {len(new_history)}/{len(symbols)} mã sẵn sàng.")

# =============================================================================
# BƯỚC 5B2: KIỂM TRA CACHE NHANH TRƯỚC KHI QUÉT
# =============================================================================
CACHE_CHECK_SYMBOL = 'HPG'
SESSION_MORNING_START = 85500
SESSION_MORNING_END = 113000
SESSION_AFTERNOON_START = 130000
SESSION_AFTERNOON_END = 150000

def _is_trading_session_time(current_date: date, now_time: int) -> bool:
    if current_date.weekday() >= 5:
        return False
    return (
        SESSION_MORNING_START <= now_time <= SESSION_MORNING_END or
        SESSION_AFTERNOON_START <= now_time <= SESSION_AFTERNOON_END
    )

def _next_trading_session_label(now_time: int) -> str:
    if now_time < SESSION_MORNING_START:
        return "08:55"
    if now_time < SESSION_AFTERNOON_START:
        return "13:00"
    return "08:55 ngày mai"

def _expected_last_session(current_date: date, now_time: int) -> date:
    """Trả về ngày nến kỳ vọng của cache dựa trên mốc 15h00."""
    expected = (pd.Timestamp(current_date) - pd.tseries.offsets.BDay(1)).date()
    if current_date.weekday() < 5 and now_time >= 150000:
        expected = current_date
    return expected

def _cache_is_fresh(df_hist, current_date: date, now_time: int) -> bool:
    if df_hist is None or len(df_hist) == 0:
        return False
    return df_hist.index[-1].date() >= _expected_last_session(current_date, now_time)

def check_and_rebuild_cache_if_stale(symbols: list, current_date: date) -> bool:
    """Kiểm tra cache qua 1 mã mẫu, rebuild nếu lệch phiên."""
    now_obj  = datetime.now(TZ_VN)
    ts       = now_obj.strftime('%H:%M:%S')
    now_time = int(now_obj.strftime("%H%M%S"))

    with cache_lock:
        check_sym = CACHE_CHECK_SYMBOL if CACHE_CHECK_SYMBOL in history_cache else (
            next(iter(history_cache), None)
        )
        sample_df = history_cache.get(check_sym) if check_sym else None

    expected = _expected_last_session(current_date, now_time)
    if _cache_is_fresh(sample_df, current_date, now_time):
        print(f"🔄 [{ts}] [Kiểm tra định kỳ 30p] Cache OK: {len(symbols)}/{len(symbols)} mã.")
        return True

    reason = "không có dữ liệu" if sample_df is None else f"nến cuối = {sample_df.index[-1].date()}"
    print(f"⚠️ [{ts}] [Kiểm tra định kỳ 30p] Cache STALE ({reason}) → Cập nhật lại {len(symbols)} mã...")
    build_history_cache(symbols, current_date)
    return False

def fetch_today_bar(symbol: str, current_date: date):
    for attempt in range(3):
        try:
            df_raw = _fetch_history_candles(symbol, limit=5)
            if df_raw is None or df_raw.empty: return None
            
            today_rows = df_raw[df_raw.index.date == current_date]
            if today_rows.empty: return None

            row    = today_rows.iloc[-1]
            close  = float(row.get('close',  np.nan))
            open_  = float(row.get('open',   close))
            high   = float(row.get('high',   close))
            low    = float(row.get('low',    close))
            volume = float(row.get('volume', np.nan))

            if pd.isna(close) or close <= 0: return None
            if pd.isna(volume) or volume < 100: return None

            prev_rows = df_raw[df_raw.index.date < current_date]
            if not prev_rows.empty:
                prev = prev_rows.iloc[-1]
                prev_close  = float(prev.get('close',  np.nan))
                prev_volume = float(prev.get('volume', np.nan))
                prev_open   = float(prev.get('open',   np.nan))
                prev_high   = float(prev.get('high',   np.nan))
                prev_low    = float(prev.get('low',    np.nan))

                ohlcv_clone = (
                    close == prev_close and open_ == prev_open and
                    high == prev_high and low == prev_low and
                    (volume == prev_volume or (prev_volume > 0 and abs(volume - prev_volume) / prev_volume < 0.01))
                )
                if ohlcv_clone:
                    print(f"    ⚠️  {symbol}: today_bar OHLCV ≈ phiên trước → bỏ qua")
                    return None

                price_vol_clone = (
                    not pd.isna(prev_close) and close == prev_close and
                    not pd.isna(prev_volume) and (volume == prev_volume or (prev_volume > 0 and abs(volume - prev_volume) / prev_volume < 0.01))
                )
                if price_vol_clone:
                    print(f"    ⚠️  {symbol}: close+volume ≈ phiên trước → bỏ qua")
                    return None

            high = max(high, open_, close)
            low  = min(low,  open_, close)

            return pd.Series(
                {'open': open_, 'high': high, 'low': low, 'close': close, 'volume': volume},
                name=pd.Timestamp(current_date)
            )
        except Exception as e:
            if attempt < 2: time.sleep(1)
            else: print(f"    ❌ fetch_today_bar {symbol}: {e}")
    return None

def upsert_today_bar(df_hist, today_bar):
    bar_date = pd.Timestamp(today_bar.name).date()
    last_hist_date = df_hist.index[-1].date()
    
    if last_hist_date == bar_date:
        new_row = pd.DataFrame([today_bar], index=[pd.Timestamp(today_bar.name)])
        prev_row = df_hist.iloc[-1]
        new_row['high'] = max(prev_row['high'], new_row.iloc[-1]['high'])
        new_row['low'] = min(prev_row['low'], new_row.iloc[-1]['low'])
        if prev_row['open'] > 0 and (new_row.iloc[-1]['open'] <= 0 or pd.isna(new_row.iloc[-1]['open'])):
            new_row['open'] = prev_row['open']
        if 'vpa_flag' in prev_row and pd.notna(prev_row['vpa_flag']):
            new_row['vpa_flag'] = prev_row['vpa_flag']
        return pd.concat([df_hist.iloc[:-1], new_row])
    
    if bar_date < last_hist_date:
        return df_hist
    
    if float(today_bar.get('volume', 0)) <= 0:
        return df_hist
    
    prev = df_hist.iloc[-1]
    p_c, p_o, p_h, p_l, p_v = float(prev['close']), float(prev['open']), float(prev['high']), float(prev['low']), float(prev['volume'])
    t_c, t_o, t_h, t_l = float(today_bar.get('close', 0)), float(today_bar.get('open', 0)), float(today_bar.get('high', 0)), float(today_bar.get('low', 0))
    t_v = float(today_bar.get('volume', 0))
    
    # Khớp toàn bộ 4 mức giá O, H, L, C và khối lượng tương đồng (lệch < 1%) -> clone của phiên trước
    if (t_c == p_c and t_o == p_o and t_h == p_h and t_l == p_l and 
        (t_v == p_v or (p_v > 0 and abs(t_v - p_v) / p_v < 0.01))):
        return df_hist
    
    new_row = pd.DataFrame([today_bar], index=[pd.Timestamp(today_bar.name)])
    new_row['vpa_flag'] = 0
    return pd.concat([df_hist, new_row])

def sync_heatmap_to_history(h_data: dict):
    """Được gọi từ dashboard_server mỗi khi heatmap lấy giá SSI 5s thành công.
    Ép thẳng giá mới vào history_cache để cập nhật realtime mượt mà."""
    now_ts = time.time()
    now_vn = datetime.now(TZ_VN)
    now_time = int(now_vn.strftime("%H%M%S"))
    default_date = _expected_last_session(now_vn.date(), now_time)
    for symbol, row in h_data.items():
        if symbol not in cache_symbol_set:
            continue
        try:
            bar_date_str = row.get('date')
            bar_date = pd.Timestamp(bar_date_str).date() if bar_date_str else default_date
            today_bar = pd.Series({
                'open': float(row.get('open', 0)),
                'high': float(row.get('high', 0)),
                'low': float(row.get('low', 0)),
                'close': float(row.get('price', 0)),
                'volume': float(row.get('volume', 0))
            }, name=pd.Timestamp(bar_date))
            
            with cache_lock:
                if symbol in history_cache and history_cache[symbol] is not None and len(history_cache[symbol]) >= 60:
                    history_cache[symbol] = upsert_today_bar(history_cache[symbol], today_bar)
            last_bar_update[symbol] = now_ts
        except Exception as e:
            pass

def chart_symbol_status(symbol: str) -> dict:
    """Kiểm tra trạng thái cache cho symbol (không gọi mạng)."""
    symbol = symbol.upper().strip()
    now = datetime.now(TZ_VN)
    current_date = now.date()
    now_time = int(now.strftime("%H%M%S"))

    with cache_lock:
        df_hist = history_cache.get(symbol)
    has_cache = df_hist is not None and len(df_hist) >= 60

    if not has_cache:
        return {"symbol": symbol, "cached": False, "need_fetch": True, "reason": "no_cache"}

    if not _cache_is_fresh(df_hist, current_date, now_time):
        return {"symbol": symbol, "cached": True, "need_fetch": True, "reason": "stale_session"}

    if not _is_trading_session_time(current_date, now_time):
        return {"symbol": symbol, "cached": True, "need_fetch": False, "reason": "outside_session"}

    last_touch = last_bar_update.get(symbol, 0)
    if time.time() - last_touch < BAR_UPDATE_TTL_SEC:
        return {"symbol": symbol, "cached": True, "need_fetch": False, "reason": "recently_updated"}

    return {"symbol": symbol, "cached": True, "need_fetch": True, "reason": "live_update_due"}


def _append_chart_action(current: str, action: str) -> str:
    return action if current == "skip" else f"{current}+{action}"


def ensure_symbol_live_in_cache(symbol: str) -> dict:
    symbol = symbol.upper().strip()
    now = datetime.now(TZ_VN)
    current_date = now.date()
    now_time = int(now.strftime("%H%M%S"))
    result = {"action": "skip"}

    with cache_lock:
        df_hist = history_cache.get(symbol)

    if df_hist is None or len(df_hist) < 60:
        result["action"] = "fetch_full_history"
        df_hist = load_history_for_symbol(symbol)
        if df_hist is None or len(df_hist) < 60:
            return result
        with cache_lock:
            history_cache[symbol] = df_hist
        return result

    if not _cache_is_fresh(df_hist, current_date, now_time):
        result["action"] = "fetch_full_history"
        fresh = load_history_for_symbol(symbol)
        if fresh is not None and len(fresh) >= 60:
            with cache_lock:
                history_cache[symbol] = fresh
            last_bar_update[symbol] = time.time()
            return result

    if not _is_trading_session_time(current_date, now_time):
        return result

    last_touch = last_bar_update.get(symbol, 0)
    if time.time() - last_touch < BAR_UPDATE_TTL_SEC:
        return result

    result["action"] = _append_chart_action(result["action"], "fetch_today_bar")
    today_bar = fetch_today_bar(symbol, current_date)
    last_bar_update[symbol] = time.time()
    if today_bar is None:
        return result

    with cache_lock:
        latest_hist = history_cache.get(symbol)
        if latest_hist is None or len(latest_hist) < 60:
            latest_hist = df_hist
        history_cache[symbol] = upsert_today_bar(latest_hist, today_bar)
    return result

# =============================================================================
# BƯỚC 5C: HÀM TIỆN ÍCH
# =============================================================================
def _date_str_from_df(df: pd.DataFrame) -> str:
    last_ts = pd.Timestamp(df.index[-1])
    if last_ts.tzinfo is None:
        last_ts = last_ts.tz_localize('Asia/Ho_Chi_Minh')
    return last_ts.strftime('%d/%m/%Y')

# =============================================================================
# BƯỚC 5D: HÀM LẤY DỮ LIỆU CHỈ SỐ
# =============================================================================
def fetch_index_history(symbol: str) -> pd.DataFrame | None:
    for attempt in range(3):
        try:
            df_raw = _fetch_history_candles(symbol, limit=5000)
            if df_raw is None or df_raw.empty: return None
            df_raw = df_raw.dropna(subset=['close'])
            if len(df_raw) < 10: return None
            return df_raw
        except Exception as e:
            if attempt < 2: time.sleep(1)
            else: print(f"    ❌ fetch_index_history {symbol}: {e}")
    return None

# =============================================================================
# BƯỚC 5E: HÀM LẤY DỮ LIỆU 15 PHÚT
# =============================================================================
def fetch_intraday_15m(symbol: str) -> pd.DataFrame | None:
    for attempt in range(3):
        try:
            df_raw = _fetch_history_candles(symbol, limit=200, resolution="15")
            if df_raw is None or df_raw.empty: return None
            df_raw = df_raw.dropna(subset=['close'])
            if len(df_raw) < 10: return None
            return compute_indicators(df_raw)
        except Exception as e:
            if attempt < 2: time.sleep(1)
            else: print(f"    ❌ fetch_intraday_15m {symbol}: {e}")
    return None

# =============================================================================
# BƯỚC 5F: FETCH FRESH HOÀN TOÀN CHO ON-DEMAND CHART (không dùng cache)
# =============================================================================
def fetch_fresh_for_chart(symbol: str, current_date: date) -> pd.DataFrame | None:
    """Fetch dữ liệu tươi từ server (không qua cache)."""
    for attempt in range(3):
        try:
            df_raw = _fetch_history_candles(symbol, limit=5000)
            if df_raw is None or len(df_raw) < 60: return None

            today_rows = df_raw[df_raw.index.date == current_date]
            if not today_rows.empty:
                vol_today = float(today_rows.iloc[-1].get('volume', 0) or 0)
                if vol_today < 100:
                    df_raw = df_raw[df_raw.index.date < current_date]

            if len(df_raw) < 60: return None
            return df_raw
        except Exception as e:
            if attempt < 2: time.sleep(1)
            else: print(f"    ❌ fetch_fresh_for_chart {symbol}: {e}")
    return None

# =============================================================================
# BƯỚC 6: CÁC HÀM ĐIỀU KIỆN TÍN HIỆU
# =============================================================================
def calc_pocket_pivot_vol(df):
    V = df['volume']; C = df['close']
    def down_vol(lv, lc, lcp): return ref(V,lv).where(ref(C,lc) <= ref(C,lcp), 0)
    return (
        (V>down_vol(1,1,2))&(V>down_vol(2,2,3))&(V>down_vol(3,3,4))&
        (V>down_vol(4,4,5))&(V>down_vol(5,5,6))&(V>down_vol(6,6,7))&
        ((V>ref(V,2))|(V>ref(V,1)))&(V>0.8*ref(df['VMA3'],1))
    )

def calc_break_vol(df):
    V = df['volume']
    cond_a = (
        ((V>1.10*df['VMA30'])|(V>1.10*df['VMA50'])|(V>1.15*df['VMA20']))&
        ((V>ref(V,2))|(V>ref(V,1)))&(V>0.9*df['VMA5'])&(V>0.9*ref(df['VMA3'],1))
    )
    cond_b = (
        ((V>1.5*df['VMA30'])|(V>1.5*df['VMA50'])|(V>1.5*df['VMA20']))&
        (V>0.8*ref(df['VMA2'],1))
    )
    return cond_a | cond_b

def calc_wedging(df):
    H,L,C,O,A = df['high'],df['low'],df['close'],df['open'],df['A']
    range5       = ref(hhv(H,5),1) - ref(llv(L,5),1)
    llv5_1       = ref(llv(L,5),1)
    range_close5 = ref(hhv(C,5),1) - ref(llv(C,5),1)
    cond_narrow  = range5/llv5_1 < 0.05
    cond_semi    = (range5/llv5_1<0.06)&(range_close5/llv5_1<0.02)
    ma_a3_1 = ref(A.rolling(3).mean(),1)
    ma_a2_1 = ref(A.rolling(2).mean(),1)
    two_green = (
        (ma_a2_1>0.015)&((O-ref(C,1))>=0)&((ref(O,1)-ref(C,2))>=0)&
        ((ref(O,2)-ref(C,3))>=0)&(ref(C,3)>ref(C,4))&(ref(C,1)>ref(O,1))&
        (ref(C,2)>ref(O,2))&((ref(C,1)-ref(C,2))/ref(C,2)>0.015)&
        ((ref(C,2)-ref(C,3))/ref(C,3)>0.015)&(ref(L,1)>=ref(L,2))&(ref(L,2)>=ref(L,3))
    )
    is_wedging_strong = (ma_a3_1>0.037)|(ma_a2_1>0.04)|two_green
    return cond_narrow|cond_semi|(~is_wedging_strong)

def calc_pocket_pivot_price(df):
    C,O,H,L,V = df['close'],df['open'],df['high'],df['low'],df['volume']
    wedging = calc_wedging(df)
    c1  = C >= 1.015*ref(C,1)
    c2  = ((C>df['MA5'])&calc_break_vol(df)&calc_pocket_pivot_vol(df))|(C>df['MA10'])
    c3  = (C>=df['EMA50'])|(C>=df['EMA30'])|(C>=df['EMA20'])
    c4  = ((df['EMA50']>=ref(df['EMA50'],1))|(df['EMA30']>=ref(df['EMA30'],1))|
            (df['EMA20']>=ref(df['EMA20'],1))|(df['EMA10']>=ref(df['EMA10'],1)))
    c5  = C > (ref(L,1)+ref(H,1))/2
    c6  = (((C>(H+L)/2)&(C>=O))|(((O-ref(C,1))/ref(C,1)>0.02)&((C-ref(C,1))/ref(C,1)>0.02)))
    c7  = ((H-C)/C<0.02)|(((H-C)/C>=0.02)&((C-O)/O>=1.1*(H-C)/C))
    c8  = O <= 1.08*df['MA10']
    c9  = (((O<=0.998*ref(hhv(H,6),2))&((O-df['MA10'])/df['MA10']<0.025))|
            ((O<=0.99*ref(hhv(H,6),2))&((O-df['MA10'])/df['MA10']<0.032))|
            ((O<=0.95*ref(hhv(H,6),2))&((O-df['MA10'])/df['MA10']<0.05))|
            ((O-df['MA10'])/df['MA10']<0.012))
    c10 = (O-df['MA10'])/df['MA10'] < 0.05
    c11 = (O-ref(C,2))/ref(C,2) < 0.1
    c12 = (ref(C,1)-ref(C,2))/ref(C,2) > -0.05
    c13 = (ref(C,1)-ref(df['MA10'],1))/ref(df['MA10'],1) < 0.08
    c14 = (ref(L,1)-ref(df['MA10'],1))/ref(df['MA10'],1) < 0.05
    c15 = ~(((ref(C,1)-ref(C,2))/ref(C,2)<-0.025)&
            ((ref(V,1)-ref(df['VMA50'],1))/ref(df['VMA50'],1)>0.5)&
            ((ref(V,1)-ref(df['VMA30'],1))/ref(df['VMA30'],1)>0.5)&
            (V<0.8*ref(V,1)))
    box1 = (ref(hhv(H,3),1)-ref(llv(L,3),1))/ref(llv(L,5),1) < 0.18
    box2 = (ref(hhv(H,2),1)-ref(llv(L,2),1))/ref(llv(L,2),1) < 0.12
    box3 = (ref(hhv(C,2),1)-ref(llv(C,2),1))/ref(llv(L,2),1) < 0.08
    return c1&c2&c3&c4&c5&c6&c7&c8&c9&c10&c11&c12&c13&c14&c15&box1&box2&box3&wedging

def calc_break_price(df):
    C,O,H,L,V = df['close'],df['open'],df['high'],df['low'],df['volume']
    wedging = calc_wedging(df)
    c1  = C >= 1.015*ref(C,1)
    c2  = (C>df['MA5'])&(C>df['MA10'])&((C>=df['EMA50'])|(C>=df['EMA30'])|(C>=df['EMA20']))
    c3  = ((df['EMA50']>=ref(df['EMA50'],1))|(df['EMA30']>=ref(df['EMA30'],1))|
            (df['EMA20']>=ref(df['EMA20'],1))|(df['EMA10']>=ref(df['EMA10'],1)))
    c4  = C > (ref(L,1)+ref(H,1))/2
    c5  = (ref(L,1)-ref(df['MA10'],1))/ref(df['MA10'],1) < 0.0825
    c6  = (ref(C,1)-ref(df['MA10'],1))/ref(df['MA10'],1) < 0.0825
    c7  = (O-df['MA10'])/df['MA10'] < 0.0825
    c8  = (O-ref(C,2))/ref(C,2) < 0.1
    c9  = (((C>(H+L)/2)&(C>=O))|(((O-ref(C,1))/ref(C,1)>0.02)&((C-ref(C,1))/ref(C,1)>0.02)))
    c10 = ((H-C)/C<0.02)|(((H-C)/C>=0.02)&((C-O)/O>=1.1*(H-C)/C))
    c11 = ~(((ref(C,1)-ref(C,2))/ref(C,2)<-0.025)&
            ((ref(V,1)-ref(df['VMA50'],1))/ref(df['VMA50'],1)>0.5)&
            ((ref(V,1)-ref(df['VMA30'],1))/ref(df['VMA30'],1)>0.5)&
            (V<0.8*ref(V,1)))
    box1 = (ref(hhv(H,3),1)-ref(llv(L,3),1))/ref(llv(L,5),1) < 0.18
    box2 = (ref(hhv(H,2),1)-ref(llv(L,2),1))/ref(llv(L,2),1) < 0.12
    box3 = (ref(hhv(C,2),1)-ref(llv(C,2),1))/ref(llv(L,2),1) < 0.08
    return c1&c2&c3&c4&c5&c6&c7&c8&c9&c10&c11&box1&box2&box3&wedging

def calc_prebreak_vol(df, now_time):
    V   = df['volume']
    V1  = ref(V,1); V2 = ref(V,2)
    pct = (df['close']-ref(df['close'],1))/ref(df['close'],1)
    def make_cond(vma_n, v_lo_mult, big_vma, big_v2):
        normal = (
            (pct<0.1)&
            ((V>vma_n*df['VMA30'])|(V>vma_n*df['VMA50'])|(V>vma_n*df['VMA20']))&
            ((V>v_lo_mult*V2)|(V>v_lo_mult*V1))&
            (V>vma_n*0.8*df['VMA5'])&(V>vma_n*0.8*ref(df['VMA3'],1))
        )
        big = (
            ((V>big_vma*df['VMA30'])|(V>big_vma*df['VMA50'])|(V>big_vma*df['VMA20']))&
            (V>big_v2*ref(df['VMA2'],1))
        )
        return normal | big
    if   now_time < 93000:  return make_cond(0.30,0.25,0.40,0.20)
    elif now_time < 100000: return make_cond(0.40,0.35,0.60,0.30)
    elif now_time < 103000: return make_cond(0.50,0.45,0.80,0.40)
    elif now_time < 113000: return make_cond(0.80,0.70,1.10,0.60)
    elif now_time < 133000: return make_cond(0.95,0.80,1.25,0.70)
    else:                   return make_cond(1.05,0.90,1.40,0.75)

def calc_liquidity(df):
    C, V = df['close'], df['volume']
    return (
        (C>=5)&(C*V>1_000_000)&(df['MA10']*df['VMA10']>1_000_000)&
        (df['MA15']*df['VMA15']>1_000_000)&(df['RSI14']>=29)&
        (df['VMA10']>=50_000)&(df['VMA20']>=50_000)&
        (df['VMA30']>=50_000)&(df['VMA50']>=50_000)
    )

def calc_dmbuy(df):
    C, V = df['close'], df['volume']
    return (
        (C > 5) &
        (df['VMA30'] >= 50_000) &
        (df['VMA20'] >= 50_000) &
        (df['VMA10'] >= 50_000) &
        (df['VMA50'] >= 50_000) &
        (V * C > 1_000_000) &
        (df['VMA5'] * df['MA5'] > 1_000_000) &
        (df['VMA10'] * df['MA10'] > 1_000_000) &
        (df['VMA15'] * df['MA15'] > 1_000_000)
    )

def _macd_buy_on_frame(df):
    if df is None or len(df) < 3:
        return pd.Series(False, index=df.index if df is not None else [])
    macd_cross_signal = afl_cross(df['MACD'], df['MACD_Signal'])
    macd_cross_zero = afl_cross(df['MACD'], 0)
    mb = macd_cross_signal | macd_cross_zero
    return mb | mb.shift(1, fill_value=False)

def _expand_signal_to_daily(frame_signal, daily_index, freq):
    if frame_signal is None or frame_signal.empty:
        return pd.Series(False, index=daily_index)
    signal_by_period = {
        period: bool(value)
        for period, value in zip(frame_signal.index.to_period(freq), frame_signal.astype(bool))
    }
    daily_periods = daily_index.to_period(freq)
    return pd.Series([signal_by_period.get(period, False) for period in daily_periods], index=daily_index)

def calc_macdbuy_signals(df_d):
    dmbuy = calc_dmbuy(df_d).iloc[-1]
    if not dmbuy:
        return []
    df_w = build_weekly_df(df_d)
    df_m = build_monthly_df(df_d)
    wmbuy_series = _expand_signal_to_daily(_macd_buy_on_frame(df_w), df_d.index, 'W-FRI')
    mmbuy_series = _expand_signal_to_daily(_macd_buy_on_frame(df_m), df_d.index, 'M')
    wmbuy = bool(wmbuy_series.iloc[-1])
    mmbuy = bool(mmbuy_series.iloc[-1])
    signals = []
    if wmbuy:
        signals.append("MACD_W")
    if mmbuy:
        signals.append("MACD_M")
    return signals

def calc_rtmbuy(df_d):
    if not bool(calc_dmbuy(df_d).iloc[-1]):
        return False
    df_w = build_weekly_df(df_d)
    if len(df_w) < 6:
        return False
    C, O, H = df_w['close'], df_w['open'], df_w['high']
    rtm = (
        (ref(C, 1) < ref(hhv(H, 5), 2)) &
        (ref(H, 1) < 1.05 * ref(hhv(H, 5), 2)) &
        (ref(C, 2) < ref(hhv(H, 4), 3)) &
        (ref(C, 3) < ref(hhv(H, 3), 4)) &
        (C > 0.97 * ref(hhv(H, 5), 1)) &
        (C > O) &
        (C > 0.94 * hhv(H, 5)) &
        (C < 1.15 * ref(hhv(H, 5), 1)) &
        (C > df_w['EMA10']) &
        (df_w['EMA10'] > df_w['EMA50']) &
        (df_w['EMA20'] > df_w['EMA50'])
    )
    wrtm = rtm | rtm.shift(1, fill_value=False)
    wrtm_daily = _expand_signal_to_daily(wrtm, df_d.index, 'W-FRI')
    return bool(wrtm_daily.iloc[-1])

def detect_momentum_signals(df_daily):
    signals = []
    signals.extend(calc_macdbuy_signals(df_daily))
    if calc_rtmbuy(df_daily):
        signals.append("RTM")
    return signals

# =============================================================================
# BƯỚC 6B: CÁC TÍN HIỆU MỚI
# =============================================================================
def calc_bottomfish(df):
    C, V = df['close'], df['volume']
    r    = df['RSI14']
    H, L = df['high'], df['low']
    rsi_cross = cross_above(r, pd.Series(29, index=r.index)) | \
                cross_above(r, pd.Series(30, index=r.index))
    range30    = (hhv(H, 30) - llv(L, 30)) / llv(L, 30)
    cond_range = range30 >= 0.2
    liq = (
        (C >= 5) & (C * V > 1_000_000) &
        (df['MA5']  * df['VMA5']  > 3_000_000) &
        (df['MA10'] * df['VMA10'] > 3_000_000) &
        (df['MA15'] * df['VMA15'] > 3_000_000) &
        (df['VMA30'] >= 50_000) & (df['VMA20'] >= 50_000) &
        (df['VMA10'] >= 50_000) & (df['VMA50'] >= 50_000)
    )
    return rsi_cross & cond_range & liq

def calc_bottombreakp(df):
    C, O, H, L, V = df['close'], df['open'], df['high'], df['low'], df['volume']
    r = df['RSI14']
    rsi_cross_today = cross_above(r, pd.Series(29, index=r.index))
    rsi_cross_prev  = cross_above(r.shift(1), pd.Series(29, index=r.index))
    rsi_cond        = rsi_cross_today | rsi_cross_prev
    high_close_bar  = (
        ((C > (H + L) / 2) & (C >= O)) |
        (((O - ref(C, 1)) / ref(C, 1) > 0.02) & ((C - ref(C, 1)) / ref(C, 1) > 0.02))
    )
    short_wick  = (
        ((H - C) / C < 0.02) |
        (((H - C) / C >= 0.02) & ((C - O) / O >= 1.1 * (H - C) / C))
    )
    price_cond  = (C >= 1.015 * ref(C, 1)) & (C > (ref(L, 1) + ref(H, 1)) / 2)
    range30     = (hhv(H, 30) - llv(L, 30)) / llv(L, 30)
    cond_range  = range30 >= 0.2
    bvol        = calc_break_vol(df)
    liq = (
        (C >= 5) & (C * V > 3_000_000) &
        (df['MA5']  * df['VMA5']  > 3_000_000) &
        (df['MA10'] * df['VMA10'] > 3_000_000) &
        (df['MA15'] * df['VMA15'] > 3_000_000) &
        (df['VMA30'] >= 50_000) & (df['VMA20'] >= 50_000) &
        (df['VMA10'] >= 50_000) & (df['VMA50'] >= 50_000)
    )
    return rsi_cond & high_close_bar & short_wick & price_cond & cond_range & bvol & liq

def _session_time_progress(now_time: int) -> float:
    """
    Dịch lại y hệt biến Ti2 trong code AmiBroker gốc: tỉ lệ thời gian giao dịch đã
    trôi qua trong phiên hiện tại (0-1), dùng để chuẩn hoá khối lượng khớp lệnh tính
    đến thời điểm hiện tại về khối lượng kỳ vọng cho cả ngày (tổng 240 phút = phiên
    sáng 9h00-11h30 + phiên chiều 13h00-14h45, quy tròn về mốc gốc của AFL).
    Trả về 1.0 (không điều chỉnh) nếu ngoài giờ giao dịch (trước 9h00 hoặc sau 14h30) —
    giống điều kiện `Now(4)<090000 OR Now(4)>143000` trong AFL.
    """
    if now_time < 90000 or now_time > 143000:
        return 1.0
    hh = now_time // 10000
    mm = (now_time // 100) % 100
    hh_morning = hh if hh < 12 else 11
    morning_minutes_from_hour = (hh_morning - 9) * 60
    morning_minutes = 30 if now_time > 113100 else mm
    total_morning = morning_minutes_from_hour + morning_minutes
    hh_afternoon = 0 if hh < 14 else 1
    afternoon_minutes_from_hour = hh_afternoon * 60
    afternoon_minutes = mm if now_time >= 130000 else 0
    total_afternoon = afternoon_minutes_from_hour + afternoon_minutes
    total_minutes = total_morning + total_afternoon
    # Bảo vệ chia-cho-0 ở đúng mốc 09:00:00 (Tigd=0 trong AFL gốc cũng rơi vào biên này,
    # nhưng AFL không chia cho 0 nhờ may mắn của thứ tự đánh giá; ở đây chặn tường minh).
    return (total_minutes / 240) if total_minutes > 0 else (1.0 / 240)

def calc_attent(df, now_time):
    """
    ATTENT — danh sách "đáng chú ý": thanh khoản đủ tốt, giá tăng >0.5% so với hôm
    trước, và ít nhất 1 trong 2 nhóm điều kiện sau đúng:
      • Xu hướng trung hạn đang đi lên (MA50/MA30/MA20 tăng 2 phiên liên tiếp và nằm
        trên MA200), HOẶC
      • Khối lượng đang khớp nhanh hơn kỳ vọng cùng thời điểm trong ngày (so với
        trung bình 30/50 phiên, đã chuẩn hoá theo % thời gian phiên đã trôi qua) và
        giá đang trên MA10 — tức dòng tiền vào sớm hơn/mạnh hơn bình thường.
    Dịch lại 1:1 biến ATTENT trong code AmiBroker gốc.
    """
    C, V = df['close'], df['volume']
    liq = (
        (C >= 5) &
        (df['VMA30'] >= 50_000) & (df['VMA20'] >= 50_000) &
        (df['VMA10'] >= 50_000) & (df['VMA50'] >= 50_000) &
        (df['MA5']  * df['VMA5']  > 1_000_000) &
        (df['MA10'] * df['VMA10'] > 1_000_000) &
        (df['MA15'] * df['VMA15'] > 1_000_000) &
        (df['MA20'] * df['VMA20'] > 1_000_000)
    )
    price_up = (C / ref(C, 1)) > 1.005
    ti2 = _session_time_progress(now_time)
    vol_pace_50 = ((V / df['VMA50']) / ti2) > 1.2
    vol_pace_30 = ((V / df['VMA30']) / ti2) > 1.2
    mid_term_up = (
        ((df['MA50'] >= ref(df['MA50'], 1)) & (df['MA50'] >= ref(df['MA50'], 2)) & (df['MA50'] >= df['MA200'])) |
        ((df['MA30'] >= ref(df['MA30'], 1)) & (df['MA30'] >= ref(df['MA30'], 2)) & (df['MA30'] >= df['MA200'])) |
        ((df['MA20'] >= ref(df['MA20'], 1)) & (df['MA20'] >= ref(df['MA20'], 2)) & (df['MA20'] >= df['MA200'])) |
        (vol_pace_50 & (C > df['MA10'])) |
        (vol_pace_30 & (C > df['MA10']))
    )
    return liq & price_up & mid_term_up

def calc_breakvol_signal(df, now_time):
    """
    BREAKVOL — cảnh báo khối lượng "nổ" sớm trong phiên: khối lượng khớp tính đến
    thời điểm hiện tại, sau khi chuẩn hoá theo % thời gian phiên đã trôi qua, đang
    vượt 1.2 lần trung bình khối lượng 50 phiên, đồng thời giá đang tăng so với hôm
    trước. Dịch lại 1:1 biến BREAKVOL trong code AmiBroker gốc (không kèm điều kiện
    thanh khoản/liquidity — đúng như bản gốc chỉ xét khối lượng + giá tăng).
    """
    C, V = df['close'], df['volume']
    ti2 = _session_time_progress(now_time)
    vol_pace = ((V / df['VMA50']) / ti2) > 1.2
    return vol_pace & (C > ref(C, 1))

def calc_ma_cross(df):
    C, V = df['close'], df['volume']
    ma_cross_cond = (
        cross_above(df['MA10'], df['MA20']) |
        cross_above(df['MA10'], df['MA30']) |
        cross_above(df['MA10'], df['MA50'])
    )
    ma_above_200 = (
        (df['MA10'] > df['MA200']) &
        (df['MA30'] > df['MA200']) &
        (df['MA50'] > df['MA200'])
    )
    price_cond = (C > df['MA30']) & (C <= 1.07 * df['MA30'])
    liq = (
        (C >= 5) & (C * V > 1_000_000) &
        (df['MA5']  * df['VMA5']  > 3_000_000) &
        (df['MA10'] * df['VMA10'] > 3_000_000) &
        (df['MA15'] * df['VMA15'] > 3_000_000) &
        (df['VMA30'] >= 50_000) & (df['VMA20'] >= 50_000) &
        (df['VMA10'] >= 50_000) & (df['VMA50'] >= 50_000)
    )
    return ma_cross_cond & ma_above_200 & price_cond & liq

# =============================================================================
# BƯỚC 6C: HÀM DETECT_SIGNAL
# =============================================================================
def detect_signal(df, now_time):
    df = compute_indicators(df)
    if len(df) < 60: return None
    liq         = calc_liquidity(df)
    break_price = calc_break_price(df)
    break_vol   = calc_break_vol(df)
    pprice      = calc_pocket_pivot_price(df)
    pvol        = calc_pocket_pivot_vol(df)
    ma10_ok = df['MA10'] >= 0.8 * ref(df['MA10'], 1)

    is_breakout = (break_price & break_vol & liq).iloc[-1]
    is_pocket   = (pprice & (pvol | break_vol) & liq & ma10_ok).iloc[-1]

    if is_breakout and is_pocket: return 'PK-BREAK'
    if is_breakout:     return 'BREAKOUT'
    if is_pocket:       return 'PK-PIVOT'

    if 91700 < now_time < 150000:
        if ((break_price | pprice) & calc_prebreak_vol(df, now_time) & liq).iloc[-1]:
            return 'PRE-BREAK'

    if calc_bottombreakp(df).iloc[-1]: return 'BT-BREAK'
    if calc_ma_cross(df).iloc[-1]:     return 'MA-CROSS'
    if calc_bottomfish(df).iloc[-1]:   return 'BOT-FISH'
    
    return None

def calc_signals_for_df(df):
    if df is None or len(df) < 60: return None, []
    try:
        now = datetime.now(TZ_VN)
        now_time = now.hour * 10000 + now.minute * 100 + now.second

        df_ind = compute_indicators(df)
        liq, bp, bv, pp, pv = calc_liquidity(df_ind), calc_break_price(df_ind), calc_break_vol(df_ind), calc_pocket_pivot_price(df_ind), calc_pocket_pivot_vol(df_ind)
        bo = bp & bv & liq
        pk = pp & (pv | bv) & liq & (df_ind['MA10'] >= 0.8 * ref(df_ind['MA10'], 1))
        bb = calc_bottombreakp(df_ind)
        
        # Lịch sử chỉ lấy 4 nấc uy tín
        any_buy_hist = bo | pk | bb
        hist = [dt.strftime('%Y-%m-%d') if hasattr(dt, 'strftime') else str(dt)[:10] for dt in df_ind.index[any_buy_hist]] if len(df_ind) > 0 and any_buy_hist.any() else []
        
        # Hôm nay quét trọn bộ 7 nấc
        last_bo, last_pk = bo.iloc[-1], pk.iloc[-1]
        last_sig = None
        
        if last_bo and last_pk: 
            last_sig = 'PK-BREAK'
        elif last_bo: 
            last_sig = 'BREAKOUT'
        elif last_pk: 
            last_sig = 'PK-PIVOT'
        else:
            if 91700 < now_time < 150000:
                if ((bp | pp) & calc_prebreak_vol(df_ind, now_time) & liq).iloc[-1]:
                    last_sig = 'PRE-BREAK'
            
            if not last_sig:
                if bb.iloc[-1]: 
                    last_sig = 'BT-BREAK'
                elif calc_ma_cross(df_ind).iloc[-1]: 
                    last_sig = 'MA-CROSS'
                elif calc_bottomfish(df_ind).iloc[-1]: 
                    last_sig = 'BOT-FISH'
        
        last_info = {"signal": last_sig, "emoji": SIGNAL_EMOJI.get(last_sig, "📌"), "label": last_sig} if last_sig else None
        
        return last_info, hist
    except Exception:
        return None, []

# =============================================================================
# BƯỚC 7: VẼ BIỂU ĐỒ
# =============================================================================
_draw_pool = ProcessPoolExecutor(max_workers=1)  # vẽ chart (matplotlib) ở process riêng, khỏi tranh GIL với Flask

def draw_chart(df_plot, symbol, signal_type, today, timeframe='Daily', add_arrow=True, date_str=None, as_bytes=False):
    is_daily  = (timeframe == 'Daily')
    is_weekly = (timeframe == 'Weekly')
    is_15m    = (timeframe == '15m')

    if date_str is None:
        date_str = _date_str_from_df(df_plot)

    prev_close = df_plot['close'].iloc[-2]
    pct        = (today['close'] - prev_close) / prev_close * 100

    hist_val    = df_plot['MACD_Hist'].values
    macd_colors = []
    for i, val in enumerate(hist_val):
        prev = hist_val[i-1] if i > 0 else 0
        if val >= 0: macd_colors.append('#26A69A' if val >= prev else '#B2DFDB')
        else:        macd_colors.append('#EF5350' if val <= prev else '#FFCDD2')

    colors_vol = ['#26A69A' if r['close'] >= r['open'] else '#EF5350'
                  for _, r in df_plot.iterrows()]

    apds = [
        mpf.make_addplot(df_plot['EMA10'],       color='red',    width=0.6),
        mpf.make_addplot(df_plot['EMA20'],       color='green',  width=0.6),
        mpf.make_addplot(df_plot['EMA50'],       color='purple', width=0.6),
        mpf.make_addplot(df_plot['volume'],      type='bar', panel=1, color=colors_vol, alpha=1.0),
        mpf.make_addplot(df_plot['MACD_Hist'],   type='bar', panel=2, color=macd_colors, secondary_y=False),
        mpf.make_addplot(df_plot['MACD'],        panel=2, color='blue',   width=0.6, secondary_y=False),
        mpf.make_addplot(df_plot['MACD_Signal'], panel=2, color='orange', width=0.6, secondary_y=False),
    ]

    if is_daily:
        apds.append(mpf.make_addplot(df_plot['MA200'],  color='brown', width=0.6))
    if is_15m:
        apds.append(mpf.make_addplot(df_plot['EMA200'], color='brown', width=0.6))

    mc           = mpf.make_marketcolors(up='#26A69A',down='#EF5350',edge='inherit',wick='inherit',alpha=1.0)
    custom_style = mpf.make_mpf_style(base_mpf_style='charles',marketcolors=mc,gridstyle='',facecolor='white')

    img_name = None
    if not as_bytes:
        fd, img_name = tempfile.mkstemp(suffix=f'_{symbol}_{timeframe.lower()}.png')
        os.close(fd)

    fig, axlist = mpf.plot(
        df_plot, type='candle', volume=False, addplot=apds,
        style=custom_style,
        figratio=(16,9), returnfig=True, show_nontrading=False, tight_layout=True
    )
    ax_price = axlist[0]
    ax_price.yaxis.set_label_position("right"); ax_price.yaxis.tick_right()
    ax_price.set_ylabel(""); ax_price.tick_params(axis='y', labelsize=8)
    y_min, y_max = ax_price.get_ylim()
    ax_price.set_ylim(y_min, y_max + (y_max-y_min)*0.15)

    if is_daily and add_arrow:
        ax_price.annotate(r'$\mathbf{\uparrow}$',
            xy=(len(df_plot)-1, today['low']), xytext=(0,-8), textcoords='offset points',
            ha='center', va='top', color='DeepPink', fontsize=12)

    if is_daily:
        title_str = (
            f"{symbol} [D] {date_str}  |  "
            f"O:{today['open']:.2f}  H:{today['high']:.2f}  "
            f"L:{today['low']:.2f}  C:{today['close']:.2f} ({pct:+.2f}%) \n\n"
            f"{signal_type}"
        )
    elif is_weekly:
        title_str = (
            f"{symbol} [W] {date_str}  | "
            f"O:{today['open']:.2f}  H:{today['high']:.2f}  "
            f"L:{today['low']:.2f}  C:{today['close']:.2f} ({pct:+.2f}%)"
        )
    else:  # 15m
        last_ts = pd.Timestamp(df_plot.index[-1])
        if last_ts.tzinfo is None:
            last_ts = last_ts.tz_localize('Asia/Ho_Chi_Minh')
        date_str_15m = last_ts.strftime('%d/%m/%Y %H:%M')
        title_str = (
            f"{symbol} [15m] {date_str_15m}  | "
            f"O:{today['open']:.2f}  H:{today['high']:.2f}  "
            f"L:{today['low']:.2f}  C:{today['close']:.2f} ({pct:+.2f}%)"
        )

    ax_price.set_title(title_str, loc='left', fontsize=11)

    if len(axlist) > 4:
        ax_macd = axlist[4]
        ax_macd.yaxis.set_ticks([]); ax_macd.yaxis.set_ticklabels([])
        m_vals = pd.concat([df_plot['MACD'],df_plot['MACD_Signal'],df_plot['MACD_Hist']]).dropna()
        if len(m_vals) == 0 or m_vals.empty:
            abs_m = 1
        else:
            try:
                abs_m = max(abs(m_vals.min()), abs(m_vals.max()))
                if abs_m == 0 or np.isnan(abs_m): abs_m = 1
            except Exception:
                abs_m = 1
        ax_macd.set_ylim(-abs_m*0.8, abs_m*1.2)
        for spine in ['top','right','left','bottom']: ax_macd.spines[spine].set_visible(False)

    for i, ax in enumerate(axlist):
        if i not in [0,4]: ax.set_axis_off()
        else: ax.xaxis.set_visible(False); ax.spines['top'].set_visible(False); ax.spines['left'].set_visible(False)

    xlim = ax_price.get_xlim()
    ax_price.set_xlim(xlim[0], xlim[1]+20)
    if as_bytes:
        buf = BytesIO()
        fig.savefig(buf, format='png', bbox_inches='tight', pad_inches=0.15, dpi=150)
        png_bytes = buf.getvalue()
        buf.close()
        plt.close('all')
        return png_bytes
    fig.savefig(img_name, bbox_inches='tight', pad_inches=0.15, dpi=150)
    plt.close('all')
    return img_name


def _build_15m_chart(symbol: str, signal_type: str, via: str = "telegram_15m") -> str | None:
    df_15m = fetch_intraday_15m(symbol)
    if df_15m is None or len(df_15m) < 2:
        print(f"  ⚠️  {symbol}: không có dữ liệu 15m")
        return None
    today_15m    = df_15m.iloc[-1]
    date_str_15m = _date_str_from_df(df_15m)
    print(f"  [Chart] {symbol} | cache_state=intraday_15m | action=fetch_intraday_15m | source=vndirect_15m | last_bar={df_15m.index[-1]} | via={via}")
    return draw_chart(
        df_15m.tail(200).copy(), symbol, signal_type, today_15m,
        timeframe='15m', add_arrow=False, date_str=date_str_15m
    )

# =============================================================================
# BƯỚC 8: HÀM QUÉT 1 CHU KỲ (VNDIRECT BATCH + DCHART FALLBACK)
# =============================================================================
SIGNAL_RANK  = {
    'PRE-BREAK': 1,
    'BOT-FISH':  2,
    'MA-CROSS':  3,
    'BT-BREAK':  4,
    'PK-PIVOT':  5,
    'BREAKOUT':  6,
    'PK-BREAK':  7,
}
SIGNAL_EMOJI = {
    'BREAKOUT':  '🟢',
    'PK-PIVOT':  '🟡',
    'PRE-BREAK': '🟣',
    'BOT-FISH':  '🟠',
    'BT-BREAK':  '🔵',
    'MA-CROSS':  '⚪',
    'PK-BREAK':  '🟢',
}

def _async_draw_and_send(df_plot_d, df_merged, symbol, signal_type, today, date_str, msg, notify_text):
    try:
        img_daily  = draw_chart(df_plot_d, symbol, signal_type, today, 'Daily', True, date_str)
        
        df_weekly  = build_weekly_df(df_merged)
        df_plot_w  = df_weekly.tail(200).copy()
        today_w    = df_plot_w.iloc[-1]
        date_str_w = _date_str_from_df(df_merged)
        img_weekly = draw_chart(df_plot_w, symbol, signal_type, today_w, 'Weekly', False, date_str_w)
        
        img_15m    = _build_15m_chart(symbol, signal_type, "scanner_signal_15m")

        image_paths = [img_daily, img_weekly]
        if img_15m: image_paths.append(img_15m)

        send_telegram_signal(msg, image_paths=image_paths, notify_text=notify_text)
    except Exception as e:
        print(f"  ❌ Lỗi chạy ngầm mã {symbol}: {e}")

def run_scan_cycle(symbols: list, now_time: int, alerted_today: dict, momentum_today: dict,
                    attent_today: dict = None, breakvol_today: dict = None):
    new_signals  = []
    current_momentum = {}
    current_attent   = {}
    current_breakvol = {}
    current_date = datetime.now(TZ_VN).date()
    ts           = datetime.now(TZ_VN).strftime('%H:%M:%S')

    now_ts = time.time()
    with cache_lock:
        all_cached_keys = list(history_cache.keys())
    ssi_query_list = [s for s in all_cached_keys if s not in ("VNINDEX", "VN30", "HNX", "UPCOM")]
    ssi_updated = set()
    for it in (_fetch_priceboard_batch(ssi_query_list) or []):
        sym = str(it.get('stockSymbol') or '').upper().strip()
        close = float(it.get('matchedPrice') or it.get('refPrice') or 0)
        if not sym or close <= 0: continue
        o, hi, lo = float(it.get('openPrice') or close), float(it.get('highest') or close), float(it.get('lowest') or close)
        bar = pd.Series({'open': o, 'high': max(hi, o, close), 'low': min(lo, o, close), 'close': close,
                         'volume': float(it.get('nmTotalTradedQty') or 0)}, name=pd.Timestamp(current_date))
        with cache_lock:
            if sym in history_cache and history_cache[sym] is not None and len(history_cache[sym]) >= 60:
                history_cache[sym] = upsert_today_bar(history_cache[sym], bar)
        last_bar_update[sym] = now_ts
        ssi_updated.add(sym)

    missing_scan = [s for s in symbols if s not in ssi_updated]
    missing_extra = [s for s in ssi_query_list if s not in ssi_updated and s not in symbols]

    def _fallback_fetch(sym_list):
        if not sym_list: return
        with ThreadPoolExecutor(max_workers=min(4, len(sym_list))) as exc:
            for s, fut in {s: exc.submit(fetch_today_bar, s, current_date) for s in sym_list}.items():
                try:
                    b = fut.result()
                    if b is not None:
                        with cache_lock:
                            if s in history_cache and history_cache[s] is not None and len(history_cache[s]) >= 60:
                                history_cache[s] = upsert_today_bar(history_cache[s], b)
                    last_bar_update[s] = time.time()
                except Exception: pass

    threading.Thread(target=lambda: (_fallback_fetch(missing_extra), [ensure_symbol_live_in_cache(i) for i in ("VNINDEX", "VN30")]), daemon=True).start()

    if missing_scan:
        _fallback_fetch(missing_scan)
        ssi_cnt = len(symbols) - len(missing_scan)
        source_tag = "[⚠️ Fallback VND 100%]" if ssi_cnt == 0 else f"[SSI: {ssi_cnt} | ⚠️ Fallback VND: {len(missing_scan)}]"
    else:
        source_tag = "[SSI 100%]"

    for symbol in all_cached_keys:
        try:
            with cache_lock: 
                df_merged = history_cache.get(symbol)
                
            if df_merged is None or len(df_merged) < 60: continue
            if df_merged.index[-1].date() != current_date: continue
            df_merged = df_merged.copy()
            try:
                if len(df_merged) >= 140:
                    today_vpa = int(calc_vpa_flag(df_merged.tail(200)).iloc[-1])
                    df_merged.loc[df_merged.index[-1], 'vpa_flag'] = today_vpa
                    with cache_lock:
                        if symbol in history_cache and history_cache[symbol] is not None and len(history_cache[symbol]) > 0:
                            history_cache[symbol].loc[df_merged.index[-1], 'vpa_flag'] = today_vpa
            except Exception:
                pass
            
            if symbol not in symbols:
                continue

            df_merged = compute_indicators(df_merged)

            try:
                momentum_signals = detect_momentum_signals(df_merged)
                if momentum_signals:
                    mom_pct = (df_merged['close'].iloc[-1] - df_merged['close'].iloc[-2]) / df_merged['close'].iloc[-2] * 100
                    current_momentum[symbol] = {"signals": momentum_signals, "pct": round(mom_pct, 1)}
            except Exception as e:
                print(f"    ⚠️  Momentum {symbol}: {e}")

            try:
                if len(df_merged) >= 60:
                    pct_today = (df_merged['close'].iloc[-1] - df_merged['close'].iloc[-2]) / df_merged['close'].iloc[-2] * 100
                    if bool(calc_attent(df_merged, now_time).iloc[-1]):
                        current_attent[symbol] = {"pct": round(pct_today, 1)}
                    if bool(calc_breakvol_signal(df_merged, now_time).iloc[-1]):
                        current_breakvol[symbol] = {"pct": round(pct_today, 1)}
            except Exception as e:
                print(f"    ⚠️  ATTENT/BREAKVOL {symbol}: {e}")

            signal_type = detect_signal(df_merged, now_time)
            first_ts = datetime.now(TZ_VN).strftime('%H:%M:%S')
            today    = df_merged.iloc[-1]
            pct      = (today['close']-df_merged['close'].iloc[-2])/df_merged['close'].iloc[-2]*100

            if not signal_type:
                if symbol in alerted_today and isinstance(alerted_today[symbol], dict):
                    alerted_today[symbol]["state"] = "DEAD"
                continue

            prev_entry = alerted_today.get(symbol)
            prev_sig   = prev_entry["signal"] if isinstance(prev_entry, dict) else prev_entry
            prev_first = prev_entry.get("first_seen", first_ts) if isinstance(prev_entry, dict) else first_ts
            prev_rank  = SIGNAL_RANK.get(prev_sig, 0)
            current_rank = SIGNAL_RANK.get(signal_type, 0)

            if isinstance(prev_entry, dict):
                prev_entry["state"] = "ALIVE"

            if prev_rank >= current_rank:
                continue

            date_str     = _date_str_from_df(df_merged)
            change       = today['close'] - df_merged['close'].iloc[-2]
            emoji        = SIGNAL_EMOJI.get(signal_type, '📌')
            vol_vs_prev  = (today['volume']-df_merged['volume'].iloc[-2])/df_merged['volume'].iloc[-2]*100
            vol_vs_vma50 = (today['volume']-today['VMA50'])/today['VMA50']*100 if today['VMA50']>0 else 0

            alerted_today[symbol] = {
                "signal": signal_type,
                "state": "ALIVE",
                "first_seen": prev_first,
                "pct": round(pct, 1),
                "price": round(float(today['close']), 2)
            }
            new_signals.append(symbol)

            link_vnd_detail  = f"https://dstock.vndirect.com.vn/tong-quan/{symbol}/diem-nhan-co-ban-popup"
            link_vnd_news    = f"https://dstock.vndirect.com.vn/tong-quan/{symbol}/tin-tuc-ma-popup?type=dn"
            link_vietstock   = f"https://stockchart.vietstock.vn/?stockcode={symbol}"
            link_vnd_summary = f"https://dstock.vndirect.com.vn/tong-quan/{symbol}"
            link_24h_money   = f"https://24hmoney.vn/stock/{symbol}/news"

            msg = (
                f"{emoji} #{symbol}  {date_str} \n"
                f"Sig: {signal_type} \n"
                f"Clo: <b>{today['close']:.2f}</b> ({change:+.2f} / {pct:+.2f}%)\n"
                f"Vol: {vol_vs_prev:+.1f}% | {vol_vs_vma50:+.1f}% \n"
                f"<a href='{link_vnd_detail}'>⚖️</a> "
                f"<a href='{link_vnd_news}'>🗞️</a> "
                f"<a href='{link_vietstock}'>📈</a> "
                f"<a href='{link_vnd_summary}'>📄</a> "
                f"<a href='{link_24h_money}'>📄</a>"
            )

            notify_text = f"{emoji} #{symbol} | {signal_type} | {date_str}"
            _draw_pool.submit(
                _async_draw_and_send,
                df_merged.tail(250).copy(),
                df_merged.copy(),
                symbol, signal_type,
                today.copy(), date_str, msg, notify_text
            )

        except Exception as e:
            print(f"  ❌ Lỗi mã {symbol}: {e}")

    momentum_today.clear()
    momentum_today.update(current_momentum)
    if attent_today is not None:
        attent_today.clear()
        attent_today.update(current_attent)
    if breakvol_today is not None:
        breakvol_today.clear()
        breakvol_today.update(current_breakvol)

    export_market_bundle(history_cache, cache_lock)
    warm_market_health_cache()
    return new_signals, source_tag

# =============================================================================
# BƯỚC 8B: PARSE LỆNH CHART
# =============================================================================
_RESERVED_KEYWORDS = {'s','help','h','scan','c','chart','heatmap','start'}

def parse_chart_command(text: str):
    text = text.strip()
    if not text.startswith('/'): return None
    body = text[1:]

    m = re.match(r'^(c|chart)\s+(.+)$', body, re.IGNORECASE)
    if m: return _filter_symbols(m.group(2).split())

    if body.startswith(' '): return _filter_symbols(body.strip().split())

    parts = body.strip().split()
    if len(parts) == 1:
        candidate = parts[0].upper()
        if candidate in INDEX_SYMBOLS:
            return [candidate]
        if candidate.lower() not in _RESERVED_KEYWORDS and _is_valid_symbol(candidate):
            return [candidate]
    return None

def _is_valid_symbol(s: str) -> bool:
    s_upper = s.upper()
    if s_upper in INDEX_SYMBOLS:
        return True
    return bool(re.match(r'^[A-Z0-9]{1,5}$', s_upper)) and s.lower() not in _RESERVED_KEYWORDS

def _filter_symbols(raw_list: list):
    result = [s.upper() for s in raw_list if _is_valid_symbol(s)]
    return result if result else None

# =============================================================================
# BƯỚC 8C: PIPELINE CHART DÙNG CHUNG — DASHBOARD + TELEGRAM
# =============================================================================
def _get_chart_context(symbol: str):
    symbol = symbol.upper().strip()
    now_obj      = datetime.now(TZ_VN)
    current_date = now_obj.date()
    now_time     = int(now_obj.strftime("%H%M%S"))
    is_index = symbol in INDEX_SYMBOLS
    trace = {
        "cache_state": "index" if is_index else "unknown",
        "action": "fetch_index_history" if is_index else "skip",
        "source": "index_api" if is_index else "unknown",
    }

    if is_index:
        df_raw = fetch_index_history(symbol)
    else:
        pre_status = chart_symbol_status(symbol)
        trace["cache_state"] = pre_status.get("reason", "unknown")
        ensure_result = ensure_symbol_live_in_cache(symbol)
        trace["action"] = ensure_result.get("action", "skip")
        with cache_lock:
            cached = history_cache.get(symbol)
            df_raw = cached.copy() if cached is not None and len(cached) >= 10 else None
        if df_raw is not None:
            trace["source"] = "history_cache"
        if df_raw is None:
            trace["action"] = _append_chart_action(trace["action"], "fetch_fresh_fallback")
            trace["source"] = "fresh_fetch"
            df_raw = fetch_fresh_for_chart(symbol, current_date)
            if df_raw is not None and len(df_raw) >= 60:
                with cache_lock:
                    history_cache[symbol] = df_raw.copy()

    if df_raw is None or len(df_raw) < 10:
        return None

    df_calc = compute_indicators(df_raw)
    today = df_calc.iloc[-1]
    signal_type = "INDEX" if is_index else (detect_signal(df_raw, now_time) or "ON-DEMAND")
    return {
        "symbol": symbol,
        "is_index": is_index,
        "source": trace["source"],
        "cache_state": trace["cache_state"],
        "action": trace["action"],
        "df_raw": df_raw,
        "df_calc": df_calc,
        "today": today,
        "signal_type": signal_type,
        "date_str": _date_str_from_df(df_calc),
    }

def _format_chart_trace(ctx):
    return (
        f"cache_state={ctx.get('cache_state', 'unknown')} | "
        f"action={ctx.get('action', 'unknown')} | "
        f"source={ctx.get('source', 'unknown')}"
    )

def _build_chart_message(ctx):
    symbol = ctx["symbol"]
    df_calc = ctx["df_calc"]
    today = ctx["today"]
    date_str = ctx["date_str"]
    pct = (today['close'] - df_calc['close'].iloc[-2]) / df_calc['close'].iloc[-2] * 100
    change = today['close'] - df_calc['close'].iloc[-2]
    vol_vs_prev = (today['volume'] - df_calc['volume'].iloc[-2]) / df_calc['volume'].iloc[-2] * 100
    vol_vs_vma50 = (today['volume'] - today['VMA50']) / today['VMA50'] * 100 if today['VMA50'] > 0 else 0

    if ctx["is_index"]:
        return (
            f"#{symbol}  {date_str}\n"
            f"Clo: <b>{today['close']:.2f}</b> ({change:+.2f} / {pct:+.2f}%)\n"
            f"Vol: {vol_vs_prev:+.1f}% | {vol_vs_vma50:+.1f}%"
        )

    link_vnd_detail  = f"https://dstock.vndirect.com.vn/tong-quan/{symbol}/diem-nhan-co-ban-popup"
    link_vnd_news    = f"https://dstock.vndirect.com.vn/tong-quan/{symbol}/tin-tuc-ma-popup?type=dn"
    link_vietstock   = f"https://stockchart.vietstock.vn/?stockcode={symbol}"
    link_vnd_summary = f"https://dstock.vndirect.com.vn/tong-quan/{symbol}"
    link_24h_money   = f"https://24hmoney.vn/stock/{symbol}/news"
    return (
        f"#{symbol}  {date_str}\n"
        f"Sig: {ctx['signal_type']}\n"
        f"Clo: <b>{today['close']:.2f}</b> ({change:+.2f} / {pct:+.2f}%)\n"
        f"Vol: {vol_vs_prev:+.1f}% | {vol_vs_vma50:+.1f}%\n"
        f"<a href='{link_vnd_detail}'>⚖️</a> "
        f"<a href='{link_vnd_news}'>🗞️</a> "
        f"<a href='{link_vietstock}'>📈</a> "
        f"<a href='{link_vnd_summary}'>📄</a> "
        f"<a href='{link_24h_money}'>📄</a>"
    )

def _build_daily_weekly_chart_paths(ctx):
    paths, labels = [], []
    symbol = ctx["symbol"]
    signal_type = ctx["signal_type"]
    try:
        path_d = draw_chart(
            ctx["df_calc"].tail(250).copy(), symbol, signal_type, ctx["today"],
            timeframe='Daily', add_arrow=False, date_str=ctx["date_str"]
        )
        paths.append(path_d)
        labels.append('📊 Daily [D]')
    except Exception as e:
        print(f"  [ChartCore] ❌ Daily {symbol}: {e}")

    try:
        df_weekly = build_weekly_df(ctx["df_raw"])
        df_plot_w = df_weekly.tail(200).copy()
        today_w = df_plot_w.iloc[-1]
        date_str_w = _date_str_from_df(ctx["df_raw"])
        path_w = draw_chart(
            df_plot_w, symbol, signal_type, today_w,
            timeframe='Weekly', add_arrow=False, date_str=date_str_w
        )
        paths.append(path_w)
        labels.append('📈 Weekly [W]')
    except Exception as e:
        print(f"  [ChartCore] ❌ Weekly {symbol}: {e}")
    return paths, labels

def _cleanup_chart_paths(paths):
    for path in paths:
        try:
            if os.path.exists(path): os.remove(path)
        except Exception:
            pass

def fetch_and_send_chart(symbol, chat_id):
    thread_id = threading.current_thread().ident
    symbol    = symbol.upper().strip()
    url_msg   = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    image_paths = []
    print(f"  🧵 [{thread_id}] fetch_and_send_chart BẮT ĐẦU: {symbol}")

    try:
        ctx = _get_chart_context(symbol)
        if ctx is None:
            requests.post(url_msg, data={
                'chat_id': chat_id,
                'text': f"❌ Không tìm thấy dữ liệu cho mã <b>{symbol}</b>",
                'parse_mode': 'HTML'
            })
            return

        print(f"  [Chart] {symbol} | {_format_chart_trace(ctx)} | last_bar={ctx['df_raw'].index[-1].date()} | via=telegram")
        image_paths, _ = _build_daily_weekly_chart_paths(ctx)
        if not ctx["is_index"]:
            img_15m = _build_15m_chart(symbol, ctx["signal_type"], via="telegram_15m")
            if img_15m: image_paths.append(img_15m)

        if not image_paths:
            requests.post(url_msg, data={
                'chat_id': chat_id,
                'text': f"❌ Không tạo được chart cho <b>{symbol}</b>",
                'parse_mode': 'HTML'
            })
            return

        print(f"  🧵 [{thread_id}] {symbol} — chuẩn bị gửi {len(image_paths)} chart")
        _send_chart_to_chat(_build_chart_message(ctx), image_paths, chat_id)
        image_paths = []
        print(f"  🧵 [{thread_id}] {symbol} — đã gửi xong")

    except Exception as e:
        print(f"  🧵 [{thread_id}] {symbol} — LỖI: {e}")
        requests.post(url_msg, data={
            'chat_id': chat_id,
            'text': f"❌ Lỗi lấy dữ liệu <b>{symbol}</b>: {e}",
            'parse_mode': 'HTML'
        })
    finally:
        _cleanup_chart_paths(image_paths)

def _send_chart_to_chat(msg, image_paths, chat_id):
    url_photo = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendPhoto"
    url_album = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMediaGroup"
    try:
        if len(image_paths) == 1:
            with open(image_paths[0], 'rb') as f:
                requests.post(url_photo, data={
                    'chat_id': chat_id, 'caption': msg or '', 'parse_mode': 'HTML'
                }, files={'photo': f})
        else:
            files, media = {}, []
            for i, path in enumerate(image_paths):
                key = f"photo{i}"; files[key] = open(path, 'rb')
                item = {"type":"photo","media":f"attach://{key}"}
                if i == 0 and msg:
                    item["caption"] = msg; item["parse_mode"] = "HTML"
                media.append(item)
            try:
                requests.post(url_album, data={
                    'chat_id': chat_id, 'media': json.dumps(media)
                }, files=files)
            finally:
                for fh in files.values(): fh.close()
    except Exception as e:
        print(f"  ❌ Lỗi gửi chart on-demand: {e}")
    finally:
        for path in image_paths:
            if os.path.exists(path): os.remove(path)

# =============================================================================
# BƯỚC 8D: CẢNH BÁO DAILY CHO DASHBOARD / TELEGRAM
# =============================================================================
def _price_alert_series_value(row, rule: dict, side: str):
    typ = rule.get(f"{side}_type")
    if typ == "price":
        return float(row.get("close", np.nan)), "Giá"
    kind = str(rule.get(f"{side}_ma_kind") or "MA").upper()
    period = int(rule.get(f"{side}_period") or 20)
    col = f"{kind}{period}"
    return float(row.get(col, np.nan)), col


def _price_alert_message(rule: dict, price: float, left_label: str, right_label: str, right_value: float) -> str:
    op = rule.get("operator")
    op_label = {
        "gte": "Tăng lên / Cắt lên",
        "lte": "Giảm về / Cắt xuống",
    }.get(op, op)
    if rule.get("right_type") == "price":
        target = f"{right_value:.2f}"
    else:
        target = right_label
    return f"{rule['symbol']} - {left_label} {op_label} {target} - Close {price:.2f}"


def _price_alert_triggered(rule: dict, prev_row, cur_row):
    left_prev, left_label = _price_alert_series_value(prev_row, rule, "left")
    left_cur, _ = _price_alert_series_value(cur_row, rule, "left")
    if rule.get("right_type") == "price":
        right_prev = right_cur = float(rule.get("right_value") or np.nan)
        right_label = "Mức giá"
    else:
        right_prev, right_label = _price_alert_series_value(prev_row, rule, "right")
        right_cur, _ = _price_alert_series_value(cur_row, rule, "right")
    vals = [left_prev, left_cur, right_prev, right_cur]
    if any(pd.isna(v) or not math.isfinite(v) for v in vals):
        return False, "", ""
    # Công thức tổng quát duy nhất cho mọi tổ hợp nguồn/đối tượng (Giá/MA vs Mức giá/MA):
    # gte: hôm qua bên trái còn thấp hơn bên phải, hôm nay đã bằng/vượt qua -> "tăng lên / cắt lên"
    # lte: hôm qua bên trái còn cao hơn bên phải, hôm nay đã bằng/thấp hơn -> "giảm về / cắt xuống"
    op = rule.get("operator")
    ok = (
        (op == "gte" and left_prev < right_prev and left_cur >= right_cur) or
        (op == "lte" and left_prev > right_prev and left_cur <= right_cur)
    )
    if not ok:
        return False, "", ""
    price = float(cur_row.get("close", np.nan))
    msg = _price_alert_message(rule, price, left_label, right_label, right_cur)
    detail = (
        f"prev_left={left_prev:.4f}; cur_left={left_cur:.4f}; "
        f"prev_right={right_prev:.4f}; cur_right={right_cur:.4f}"
    )
    return True, msg, detail


def send_price_alert_chart_to_telegram(symbol: str, chat_id: str, alert_message: str):
    if not ENABLE_TELEGRAM:
        return
    image_paths = []
    symbol = symbol.upper().strip()
    try:
        ctx = _get_chart_context(symbol)
        if ctx is None:
            return
        image_paths, _ = _build_daily_weekly_chart_paths(ctx)
        if not ctx["is_index"]:
            img_15m = _build_15m_chart(symbol, ctx["signal_type"], via="price_alert_15m")
            if img_15m:
                image_paths.append(img_15m)
        if not image_paths:
            return
        msg = f"<b>CẢNH BÁO #{symbol}</b>\n{alert_message}\n\n{_build_chart_message(ctx)}"
        _send_chart_to_chat(msg, image_paths, chat_id)
        image_paths = []
    except Exception as e:
        print(f"  [Alert] ❌ Gửi Telegram {symbol}: {e}")
    finally:
        _cleanup_chart_paths(image_paths)


def check_price_alerts():
    try:
        rules = get_active_price_alert_rules()
    except Exception as e:
        print(f"  [Alert] ❌ Không đọc được rule cảnh báo: {e}")
        return []
    if not rules:
        return []
    triggered = []
    for rule in rules:
        symbol = str(rule.get("symbol") or "").upper().strip()
        if not symbol:
            continue
        try:
            ensure_symbol_live_in_cache(symbol)
            with cache_lock:
                df_raw = history_cache.get(symbol)
                df_raw = df_raw.copy() if df_raw is not None and len(df_raw) >= 210 else None
            if df_raw is None or len(df_raw) < 2 or df_raw.index[-1].date() != datetime.now(TZ_VN).date():
                continue
            df_calc = compute_indicators(df_raw)
            prev_row = df_calc.iloc[-2]
            cur_row = df_calc.iloc[-1]
            ok, msg, detail = _price_alert_triggered(rule, prev_row, cur_row)
            if not ok:
                continue
            bar_date = pd.Timestamp(df_calc.index[-1]).strftime("%Y-%m-%d")
            price = float(cur_row.get("close", np.nan))
            event = record_price_alert_event(
                rule["id"], msg, detail, bar_date, price,
                notify_dashboard=bool(rule.get("notify_dashboard", True))
            )
            if not event:
                continue
            triggered.append(symbol)
            print(f"  [Alert] 🔔 {msg}")
            if rule.get("notify_telegram") and rule.get("telegram_chat_id"):
                threading.Thread(
                    target=send_price_alert_chart_to_telegram,
                    args=(symbol, str(rule["telegram_chat_id"]), msg),
                    daemon=True
                ).start()
        except Exception as e:
            print(f"  [Alert] ❌ {symbol}: {e}")
    return triggered

# =============================================================================
# BƯỚC 8E: HÀM DASHBOARD VOL FORECAST
# =============================================================================
def dashboard_vol_forecast_fn(symbol: str, current_vol: float = None):
    """
    Tính dự báo volume siêu tốc (0.02ms) trực tiếp từ 55 nến cuối trong RAM (history_cache),
    không gọi lại _get_chart_context() hay tính lại 24 chỉ báo.
    Nhận current_vol tùy chọn (từ nhịp 5s) để ưu tiên số volume realtime mới nhất.
    """
    symbol = symbol.upper().strip()
    try:
        with cache_lock:
            df = history_cache.get(symbol)
        if df is None or len(df) < 2:
            return {"symbol": symbol, "error": "not_enough_bars"}

        sub = df.tail(55)
        today = sub.iloc[-1]
        prev = sub.iloc[-2]
        now_obj = datetime.now(TZ_VN)
        now_time = int(now_obj.strftime("%H%M%S"))
        bar_date = pd.Timestamp(sub.index[-1]).strftime("%Y-%m-%d")
        is_today = bar_date == now_obj.strftime("%Y-%m-%d")
        progress = _session_time_progress(now_time) if is_today else 1.0

        vol = float(current_vol) if (current_vol is not None and current_vol == current_vol) else float(today.get("volume", float("nan")))
        prev_vol = float(prev.get("volume", float("nan")))
        vma50 = float(sub["volume"].tail(50).mean())
        c_val, p_val = float(today.get("close", 0.0)), float(prev.get("close", 0.0))
        pct_val = round((c_val - p_val) / p_val * 100, 2) if p_val > 0 else 0.0

        ratio_prev = (vol / prev_vol) if (prev_vol > 0 and vol == vol) else None
        ratio_ma50 = (vol / vma50) if (vma50 > 0 and vol == vol) else None

        return {
            "symbol": symbol,
            "bar_date": bar_date,
            "progress": round(progress, 4),
            "close": c_val,
            "open": float(today.get("open", c_val)),
            "pct": pct_val,
            "volume": vol if vol == vol else None,
            "prev_volume": prev_vol if prev_vol == prev_vol else None,
            "vma50": vma50 if vma50 == vma50 else None,
            "ratio_prev": round(ratio_prev, 4) if ratio_prev is not None else None,
            "ratio_ma50": round(ratio_ma50, 4) if ratio_ma50 is not None else None,
        }
    except Exception as e:
        print(f"  [VolForecast] ❌ {symbol}: {e}")
        return {"symbol": symbol, "error": "exception", "detail": str(e)}

# =============================================================================
# BƯỚC 8F: TELEGRAM LISTENER
# =============================================================================
def telegram_listener(stop_event: threading.Event):
    url_upd = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/getUpdates"
    url_msg = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    session = requests.Session()
    adapter = requests.adapters.HTTPAdapter(max_retries=1, pool_connections=5, pool_maxsize=5)
    session.mount('https://', adapter)

    offset = 0
    print(f"🎧 Listener sẵn sàng | VIP: {VIP_CHAT_IDS} | Free slot: {FREE_CHAT_LIMIT}")

    while not stop_event.is_set():
        try:
            resp = session.get(url_upd, params={
                'offset': offset, 'timeout': 30,
                'allowed_updates': ['message', 'callback_query'],
            }, timeout=35)

            if stop_event.is_set(): break

            if resp.status_code == 409:
                print("  ⚠️ HTTP 409 Conflict — có instance khác đang chạy! Đợi 15s...")
                time.sleep(15); continue
            elif resp.status_code != 200:
                print(f"  ⚠️ getUpdates HTTP {resp.status_code} — thử lại sau 5s")
                time.sleep(5); continue

            updates = resp.json().get('result', [])
            if not updates: continue

            for update in updates:
                update_id = update['update_id']
                if update_id >= offset: offset = update_id + 1
                print(f"  📨 Xử lý update_id={update_id} | offset mới={offset}")

                callback = update.get('callback_query', {})
                if callback:
                    cb_id      = callback.get('id')
                    cb_data    = callback.get('data', '')
                    cb_chat_id = str(callback.get('message', {}).get('chat', {}).get('id', ''))
                    session.post(
                        f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/answerCallbackQuery",
                        data={'callback_query_id': cb_id}
                    )
                    allowed, reason = is_allowed(cb_chat_id)
                    if allowed and cb_data.startswith('chart_'):
                        sym = cb_data.replace('chart_', '').upper()
                        print(f"  📥 Callback chart {sym} → chat_id={cb_chat_id} ({reason})")
                        threading.Thread(
                            target=fetch_and_send_chart,
                            args=(sym, cb_chat_id),
                            daemon=True
                        ).start()
                    continue

                message = update.get('message', {})
                if not message: continue

                chat_id = str(message.get('chat', {}).get('id', ''))
                text    = message.get('text', '').strip()
                if not text: continue
                text_lower = text.lower()

                allowed, reason = is_allowed(chat_id)
                if not allowed:
                    continue

                if text_lower == '/s' or text_lower.startswith('/s '):
                    if not is_vip(chat_id):
                        requests.post(url_msg, data={
                            'chat_id':    chat_id,
                            'parse_mode': 'HTML',
                            'text':       '🔒 Lệnh <b>/s</b> chỉ dành cho thành viên VIP.'
                        })
                        continue

                    if alerted_today:
                        buttons = []
                        sorted_signals = sorted(
                            alerted_today.items(),
                            key=lambda x: (
                                -SIGNAL_RANK.get(x[1]["signal"] if isinstance(x[1], dict) else x[1], 0),
                                x[0]
                            )
                        )
                        for k, v in sorted_signals:
                            sig   = v["signal"] if isinstance(v, dict) else v
                            emoji = SIGNAL_EMOJI.get(sig, '📌')
                            buttons.append([{"text": f"{emoji} #{k}: {sig}", "callback_data": f"chart_{k}"}])
                        if signal_session_date == datetime.now(TZ_VN).date():
                            reply = "📋 <b>Tín hiệu hôm nay:</b>"
                        else:
                            reply = f"📋 <b>Tín hiệu phiên gần nhất ({signal_session_date.strftime('%d/%m')}):</b>"
                    else:
                        reply   = "📋 Chưa có tín hiệu nào hôm nay."
                        buttons = []

                    payload = {
                        'chat_id':    chat_id,
                        'text':       reply,
                        'parse_mode': 'HTML',
                    }
                    if buttons:
                        payload['reply_markup'] = json.dumps({"inline_keyboard": buttons})
                    requests.post(url_msg, data=payload)

                elif text_lower in ('/h', '/heatmap', '/ h', '/ heatmap'):
                    print(f"  🗺  Lệnh heatmap từ chat_id={chat_id} ({reason})")
                    threading.Thread(
                        target=handle_heatmap_command,
                        args=(chat_id,),
                        daemon=True
                    ).start()

                elif text_lower == '/help' or text_lower.startswith('/help '):
                    vip_note = "\n\n🔒 <b>Chỉ VIP:</b> /s — Tín hiệu hôm nay" if not is_vip(chat_id) else ""
                    requests.post(url_msg, data={
                        'chat_id': chat_id, 'parse_mode': 'HTML',
                        'text': (
                            "🤖 <b>Lệnh hỗ trợ:</b>\n\n"
                            "<b>Xem chart cổ phiếu:</b>\n"
                            "/c HPG\n/chart HPG\n/HPG\n/ HPG\n"
                            "/c HPG VNM FPT  (nhiều mã, tối đa 5)\n\n"
                            "<b>Xem chart chỉ số:</b>\n"
                            "/VNINDEX  /VN30  /HNX  /UPCOM  /VN100\n\n"
                            "<b>Heatmap thị trường:</b>\n"
                            "/h  hoặc  /heatmap\n\n"
                            "<b>Khác:</b>\n"
                            "/s  — Tín hiệu hôm nay (VIP)\n"
                            "/help  — Trợ giúp\n\n"
                            "<b>Chart gửi kèm:</b> Daily [D] + Weekly [W] + 15 phút [15m]"
                            f"{vip_note}"
                        )
                    })

                else:
                    symbols = parse_chart_command(text)
                    if symbols:
                        print(f"  🔍 {text!r} → {symbols} | update_id={update_id} ({reason})")
                        for sym in symbols[:5]:
                            print(f"  📥 Chart {sym} → chat_id={chat_id}")
                            threading.Thread(
                                target=fetch_and_send_chart,
                                args=(sym, chat_id),
                                daemon=True
                            ).start()
                            time.sleep(0.3)

        except requests.exceptions.Timeout:
            continue
        except requests.exceptions.ConnectionError as e:
            if stop_event.is_set(): break
            print(f"  ❌ Connection error: {e} — thử lại sau 10s"); time.sleep(10)
        except Exception as e:
            if stop_event.is_set(): break
            print(f"  ❌ Listener lỗi: {e}"); time.sleep(5)

    print("🛑 Listener đã dừng.")

# =============================================================================
# BƯỚC 8G: LƯU/ĐỌC TRẠNG THÁI TÍN HIỆU ĐÃ GỬI (PERSIST QUA RESTART)
# Lưu/đọc trạng thái tín hiệu đã gửi (alerted_today, momentum...) qua restart
_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
_DEFAULT_DATA_DIR = os.path.join(_BASE_DIR, "data", "trade-journal")
_env_data_dir = os.environ.get("DASHBOARD_DATA_DIR")
if _env_data_dir and (_env_data_dir != "/data/trade-journal" or os.path.exists("/data/trade-journal")):
    _SIGNAL_STATE_DIR = _env_data_dir
else:
    _SIGNAL_STATE_DIR = _DEFAULT_DATA_DIR
os.makedirs(_SIGNAL_STATE_DIR, exist_ok=True)
SIGNAL_STATE_FILE = os.path.join(_SIGNAL_STATE_DIR, 'signal_state_cache.json')
MARKET_BUNDLE_FILE = os.path.join(_SIGNAL_STATE_DIR, 'market_bundle.json')
_signal_state_lock = threading.Lock()

def _format_df_bars_vols(df_in):
    bars, vols = [], []
    for idx, row in df_in.iterrows():
        dt_str = idx.strftime('%Y-%m-%d')
        o = float(row.get('open', row['close']))
        c = float(row['close'])
        h = float(row.get('high', max(o, c)))
        l = float(row.get('low', min(o, c)))
        v = float(row.get('volume', 0))
        vpa_val = row.get('vpa_flag', 0)
        flag = int(vpa_val) if pd.notna(vpa_val) else 0
        color = "#254fcc" if flag == 1 else ("#00ffe5" if flag == 2 else ("#26a69a" if c >= o else "#ef5350"))
        bars.append([dt_str, o, h, l, c])
        vols.append([dt_str, v, color])
    return bars, vols

def export_market_bundle(cache, lock, out_path=MARKET_BUNDLE_FILE):
    """Xuất toàn bộ 147 mã thành 1 file bundle JSON nén đa khung thời gian (1D, 1W, 1M) cho Cloudflare Pages & Dashboard."""
    try:
        data = {"updated_at": datetime.now(TZ_VN).strftime('%Y-%m-%d %H:%M:%S'), "symbols": {}}
        with lock:
            sym_items = list(cache.items())
        for sym, df in sym_items:
            if df is None or len(df) < 5:
                continue
            sub_df = df.tail(800)
            bars_1d, vols_1d = _format_df_bars_vols(sub_df)

            _, hist_sigs = calc_signals_for_df(sub_df)
            rs_raw = _rs_score_cache["scores"].get(sym) if _rs_score_cache and "scores" in _rs_score_cache else None
            rs_val = round(float(rs_raw), 1) if rs_raw is not None else None
            
            # Đóng gói sẵn dự báo Vol đa khung (dùng chung tiến độ ngày)
            now_obj = datetime.now(TZ_VN)
            now_time = int(now_obj.strftime("%H%M%S"))
            bar_date = pd.Timestamp(sub_df.index[-1]).strftime("%Y-%m-%d")
            is_today = bar_date == now_obj.strftime("%Y-%m-%d")
            progress = _session_time_progress(now_time) if is_today else 1.0
            
            def _get_vf(df_tf):
                if df_tf is None or len(df_tf) == 0: return None
                last_vol = float(df_tf['volume'].iloc[-1])
                prev_vol = float(df_tf['volume'].iloc[-2]) if len(df_tf) > 1 else 0
                vma50_val = float(df_tf['VMA50'].iloc[-1]) if 'VMA50' in df_tf.columns and pd.notna(df_tf['VMA50'].iloc[-1]) else (float(df_tf['volume'].tail(50).mean()) if len(df_tf) >= 10 else 0)
                return {
                    "symbol": sym,
                    "progress": round(progress, 4),
                    "ratio_prev": round(last_vol / prev_vol, 4) if prev_vol > 0 else None,
                    "ratio_ma50": round(last_vol / vma50_val, 4) if vma50_val > 0 else None,
                    "vma50": round(vma50_val, 1) if vma50_val else None
                }
            
            vf_1d = _get_vf(sub_df)

            item = {
                "candles": bars_1d,
                "volume": vols_1d,
                "history_signals": hist_sigs,
                "vol_forecast": vf_1d
            }
            if rs_val is not None:
                item["rs"] = rs_val
            data["symbols"][sym] = item
        tmp = out_path + ".tmp"
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, separators=(',', ':'))
        os.replace(tmp, out_path)
    except Exception as e:
        print(f"  ⚠️ Lỗi xuất market_bundle.json: {e}")

def _load_signal_state():
    """Đọc lại alerted_today + momentum_today + attent_today + breakvol_today đã lưu."""
    try:
        with open(SIGNAL_STATE_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        session_date_str = data.get('session_date')
        session_date = datetime.strptime(session_date_str, '%Y-%m-%d').date() if session_date_str else None
        alerted  = data.get('alerted', {}) or {}
        momentum = data.get('momentum', {}) or {}
        attent   = data.get('attent', {}) or {}
        breakvol = data.get('breakvol', {}) or {}
        print(f"  💾 Đã đọc trạng thái đã lưu: {len(alerted)} tín hiệu, {len(momentum)} động lượng, "
              f"{len(attent)} ATTENT, {len(breakvol)} BREAKVOL, phiên {session_date_str or '?'}")
        return alerted, momentum, attent, breakvol, session_date
    except FileNotFoundError:
        return {}, {}, {}, {}, None
    except Exception as e:
        print(f"  ⚠️  Lỗi đọc {SIGNAL_STATE_FILE}: {e} → bỏ qua, coi như chưa có dữ liệu lưu.")
        return {}, {}, {}, {}, None

def _save_signal_state(alerted: dict, momentum: dict, session_date: date,
                        attent: dict = None, breakvol: dict = None):
    """Ghi đè toàn bộ trạng thái tín hiệu + động lượng + ATTENT + BREAKVOL của phiên hiện tại xuống đĩa (ghi an toàn qua file tạm)."""
    try:
        with _signal_state_lock:
            tmp_path = SIGNAL_STATE_FILE + '.tmp'
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'session_date': session_date.strftime('%Y-%m-%d') if session_date else None,
                    'alerted': alerted,
                    'momentum': momentum,
                    'attent': attent or {},
                    'breakvol': breakvol or {},
                }, f, ensure_ascii=False)
            os.replace(tmp_path, SIGNAL_STATE_FILE)
    except Exception as e:
        print(f"  ⚠️  Lỗi lưu {SIGNAL_STATE_FILE}: {e}")

# =============================================================================
# BƯỚC 9: KHỞI ĐỘNG
# =============================================================================
try:
    _stop_listener.set()
    print("⏹️  Đang dừng listener cũ...")
    if 'listener_thread' in dir() and listener_thread.is_alive():
        listener_thread.join(timeout=8)
        if listener_thread.is_alive():
            print("  ⚠️ Listener cũ chưa dừng hẳn (timeout), tiếp tục...")
        else:
            print("  ✅ Listener cũ đã dừng hẳn.")
    time.sleep(1)
except NameError:
    pass

if __name__ == '__main__':
    boot_now = datetime.now(TZ_VN)
    boot_ts  = boot_now.strftime('%Y-%m-%d %H:%M:%S')
    my_pid   = os.getpid()

    print("\n" + "="*60)
    print("🚀 [HỆ THỐNG KHỞI ĐỘNG] Auto-Scanner + Dashboard")
    print(f"⏰ Thời gian : {boot_ts} | PID: {my_pid}")
    print(f"📊 Cấu hình  : {len(symbols_to_scan)} mã quét | {len(symbols_to_cache)} mã cache | Chu kỳ: {SCAN_INTERVAL_SEC}s")
    print("🌐 Dashboard : http://0.0.0.0:8888 (Tín hiệu: 10s | Heatmap/Health: 120s)")
    if ENABLE_TELEGRAM:
        print(f"🎧 Telegram  : Đang chạy (Channel: {TELEGRAM_CHAT_ID})")
    print("="*60)

    load_persisted_caches()
    alerted_today, momentum_today, attent_today, breakvol_today, signal_session_date = _load_signal_state()
    last_run_date = boot_now.date()
    if signal_session_date is None:
        signal_session_date = last_run_date
        _save_signal_state(alerted_today, momentum_today, signal_session_date, attent_today, breakvol_today)
    _last_cache_check_ts = time.time()   # cổng nhịp cho check_and_rebuild_cache_if_stale (ngoài giờ, mỗi CACHE_CHECK_INTERVAL_SEC)
    boot_time = int(boot_now.strftime("%H%M%S"))
    _last_morning_warmup_date = last_run_date if boot_time >= 83000 else None
    _last_afternoon_eod_date = last_run_date if boot_time >= 150000 else None
    _market_closed_logged = False
    _weekend_logged = False

    _stop_listener  = threading.Event()
    listener_thread = threading.Thread(target=telegram_listener, args=(_stop_listener,), daemon=True)
    if ENABLE_TELEGRAM:
        listener_thread.start()

    # Khởi động Dashboard trước để các panel phục vụ ngay, sau đó nạp cache lịch sử
    start_dashboard(
        alerted_today_ref = lambda: alerted_today,
        history_cache_ref = lambda: history_cache,
        cache_lock_ref    = cache_lock,
        fetch_heatmap_fn  = fetch_heatmap_data,
        signal_emoji_ref  = SIGNAL_EMOJI,
        signal_rank_ref   = SIGNAL_RANK,
        vol_forecast_fn   = dashboard_vol_forecast_fn,
        calc_vpa_flag_fn  = calc_vpa_flag,
        momentum_today_ref = lambda: momentum_today,
        attent_today_ref   = lambda: attent_today,
        breakvol_today_ref = lambda: breakvol_today,
        fetch_market_health_fn = compute_market_health_index,
        signal_session_date_ref = lambda: signal_session_date,
        port              = 8888,
        extra_quote_fn    = fetch_extra_quotes,
        rs_universe_ref   = lambda: symbols_to_rs,
        calc_signals_fn   = calc_signals_for_df,
        sync_heatmap_fn   = sync_heatmap_to_history,
    )

    build_history_cache(symbols_to_cache, last_run_date)
    print("🚀 Bắt đầu vòng lặp quét tự động...\n")

    # =============================================================================
    # VÒNG LẶP CHÍNH
    # =============================================================================
    while True:
        try:
            now_obj      = datetime.now(TZ_VN)
            current_date = now_obj.date()
            now_time     = int(now_obj.strftime("%H%M%S"))
            ts           = now_obj.strftime("%H:%M:%S")
            weekday      = now_obj.weekday()  # 0=Thứ 2 ... 4=Thứ 6, 5=Thứ 7, 6=Chủ nhật

            # ── BỎ QUA THỨ 7 VÀ CHỦ NHẬT ────────────────────────────────────────
            if weekday >= 5:
                day_name = "Thứ 7" if weekday == 5 else "Chủ nhật"
                if not _weekend_logged:
                    print(f"[{ts}] 📅 {day_name} — không quét. Listener + Dashboard vẫn chạy 24/7.")
                    _weekend_logged = True
                time.sleep(SCAN_INTERVAL_SEC)
                continue
            else:
                _weekend_logged = False

            if current_date > last_run_date:
                last_run_date = current_date
                print(f"\n🌅 [{ts}] Ngày mới {current_date.strftime('%d/%m/%Y')} — Reload cache lịch sử.")
                build_history_cache(symbols_to_cache, current_date)

            if not _is_trading_session_time(current_date, now_time):
                # 1. Khởi động nạp mới cache vào 08h30 sáng trước giờ giao dịch
                if 83000 <= now_time < SESSION_MORNING_START and _last_morning_warmup_date != current_date:
                    _last_morning_warmup_date = current_date
                    print(f"\n☀️ [{ts}] [Đầu ngày 08h30] Chuẩn bị phiên mới — Nạp mới dữ liệu lịch sử.")
                    build_history_cache(symbols_to_cache, current_date)

                # 2. Chốt nến phiên hôm nay sau 15h00
                if now_time >= 150000 and _last_afternoon_eod_date != current_date:
                    _last_afternoon_eod_date = current_date
                    print(f"\n🌆 [{ts}] [Chốt phiên 15h00] Cập nhật nến đóng cửa {len(symbols_to_cache)} mã.")
                    build_history_cache(symbols_to_cache, current_date)

                # 3. Kiểm tra cache định kỳ mỗi 30 phút ngoài giờ giao dịch
                if time.time() - _last_cache_check_ts >= CACHE_CHECK_INTERVAL_SEC:
                    _last_cache_check_ts = time.time()
                    check_and_rebuild_cache_if_stale(symbols_to_cache, current_date)

                next_open = _next_trading_session_label(now_time)
                if not _market_closed_logged:
                    sess_str = signal_session_date.strftime('%d/%m') if signal_session_date else current_date.strftime('%d/%m')
                    print(f"[{ts}] ⏸ Thị trường đóng cửa phiên {sess_str} → Đợi phiên {next_open} (Dashboard & Bot chạy 24/7).")
                    _market_closed_logged = True

                time.sleep(SCAN_INTERVAL_SEC)
                continue
            else:
                _market_closed_logged = False

            # Reset danh sách tín hiệu khi vào phiên mới (chỉ reset khi thực sự có nến giao dịch của hôm nay)
            with cache_lock:
                has_today_bar = any(df is not None and len(df) > 0 and df.index[-1].date() == current_date for df in history_cache.values())
            if has_today_bar and current_date > signal_session_date:
                alerted_today.clear()
                momentum_today.clear()
                attent_today.clear()
                breakvol_today.clear()
                signal_session_date = current_date
                _save_signal_state(alerted_today, momentum_today, signal_session_date, attent_today, breakvol_today)
                print(f"🌅 [{ts}] Phiên giao dịch mới {current_date.strftime('%d/%m/%Y')} — Reset danh sách tín hiệu đã gửi.")

            with cache_lock:
                cache_empty = len(history_cache) == 0
            if cache_empty:
                print(f"[{ts}] ⚠️  Cache trống — bắt buộc load trước khi quét...")
                build_history_cache(symbols_to_cache, current_date)

            new_signals, source_tag = run_scan_cycle(symbols_to_scan, now_time, alerted_today, momentum_today,
                                                      attent_today, breakvol_today)
            triggered_alerts = check_price_alerts()

            if new_signals:
                print(f"\n🔔 [{ts}] PHÁT HIỆN TÍN HIỆU MỚI ({len(new_signals)} mã):")
                for s in new_signals:
                    info = alerted_today.get(s, {})
                    sig = info.get("signal", "SIGNAL")
                    p = info.get("price", 0.0)
                    pct = info.get("pct", 0.0)
                    pct_sign = "+" if pct >= 0 else ""
                    print(f"   👉 {s}: {sig} (Giá: {p:.1f}, {pct_sign}{pct:.1f}%)")
            else:
                att_cnt = len(attent_today) if attent_today else 0
                print(f"[{ts}] 🔄 Quét {len(symbols_to_scan)} mã {source_tag} — 0 tín hiệu mới | Theo dõi: {len(alerted_today)} tín hiệu, {len(momentum_today)} động lượng, {att_cnt} ATTENT.")

            _save_signal_state(alerted_today, momentum_today, signal_session_date, attent_today, breakvol_today)
            if triggered_alerts:
                print(f"🎯 [{ts}] Cảnh báo khớp: {', '.join(triggered_alerts)}")

            print(f"⏳ Đợi {SCAN_INTERVAL_SEC}s cho chu kỳ tiếp theo...")
            time.sleep(SCAN_INTERVAL_SEC)

        except Exception as e:
            ts = datetime.now(TZ_VN).strftime("%H:%M:%S")
            print(f"[{ts}] ❌ Lỗi vòng lặp chính: {e}")
            time.sleep(10)
