import requests
import json
import time

def test_url(url, desc):
    print(f"\n--- Testing {desc} ---")
    print(f"URL: {url}")
    try:
        start = time.time()
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
        res = requests.get(url, headers=headers, timeout=10)
        t = time.time() - start
        print(f"Status: {res.status_code}, Time: {t:.2f}s")
        if res.status_code == 200:
            try:
                data = res.json()
                print("Data length/keys:", type(data), len(data) if isinstance(data, (list, dict)) else "N/A")
                if isinstance(data, dict):
                    print("Keys:", list(data.keys()))
                print("Sample:", str(data)[:300] + "...")
            except:
                print("Response is not JSON")
                print("Sample:", res.text[:200])
        else:
            print("Error text:", res.text[:200])
    except Exception as e:
        print("Exception:", e)

# Let's try some known CafeF endpoints or guess them based on the msh-appdata subdomain
test_url("https://msh-appdata.cafef.vn/rest-api/api/v1/Symbol/SSI", "Symbol Info SSI")
test_url("https://msh-appdata.cafef.vn/rest-api/api/v1/History/SSI", "History SSI")
test_url("https://finfo-api.cafef.vn/v1/historical", "Historical guess")
test_url("https://s.cafef.vn/Ajax/Data.ashx", "Ajax Data guess")

