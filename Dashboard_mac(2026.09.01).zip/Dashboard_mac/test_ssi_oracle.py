import time

URL = "https://iboard-query.ssi.com.vn/stock/multiple"
PAYLOAD = {"stocks": ["VJC", "FPT", "SSI", "HPG", "VND"]}
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json, text/plain, */*",
    "Content-Type": "application/json",
    "Origin": "https://iboard.ssi.com.vn",
    "Referer": "https://iboard.ssi.com.vn/",
}

def test_standard_requests():
    print("--- 1. TEST BẰNG THƯ VIỆN `requests` (CŨ) ---")
    try:
        import requests
        session = requests.Session()
        session.headers.update(HEADERS)
        t0 = time.time()
        res = session.post(URL, json=PAYLOAD, timeout=10)
        print(f"Status Code: {res.status_code} (Thời gian: {time.time()-t0:.2f}s)")
        if res.status_code == 200:
            data = res.json().get("data", [])
            print(f"Thành công! Lấy được {len(data)} mã.")
            for it in data[:3]:
                sym = it.get('stockSymbol')
                match = float(it.get('matchedPrice') or 0.0) / 1000.0
                print(f" - {sym}: {match}")
        else:
            print("Thất bại! Phản hồi:", res.text[:200])
    except Exception as e:
        print("Lỗi kết nối:", e)

def test_curl_cffi():
    print("\n--- 2. TEST BẰNG THƯ VIỆN `curl_cffi` (NGỤY TRANG CHROME) ---")
    try:
        from curl_cffi import requests as cffi_requests
        # Tham số impersonate="chrome120" sẽ ngụy trang TLS y hệt Chrome 120
        session = cffi_requests.Session(impersonate="chrome120")
        session.headers.update(HEADERS)
        t0 = time.time()
        res = session.post(URL, json=PAYLOAD, timeout=10)
        print(f"Status Code: {res.status_code} (Thời gian: {time.time()-t0:.2f}s)")
        if res.status_code == 200:
            data = res.json().get("data", [])
            print(f"Thành công! Lấy được {len(data)} mã.")
            for it in data[:3]:
                sym = it.get('stockSymbol')
                match = float(it.get('matchedPrice') or 0.0) / 1000.0
                print(f" - {sym}: {match}")
        else:
            print("Thất bại! Phản hồi:", res.text[:200])
    except ImportError:
        print("❌ Lỗi: Bạn chưa cài thư viện curl_cffi.")
        print("👉 Hãy gõ lệnh này trên VPS để cài đặt: pip install curl_cffi")
    except Exception as e:
        print("Lỗi kết nối:", e)

if __name__ == "__main__":
    test_standard_requests()
    test_curl_cffi()
