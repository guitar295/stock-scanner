import requests

url = "https://iboard-query.ssi.com.vn/stock/multiple"
headers = {
    'Accept': 'application/json',
    'User-Agent': 'Mozilla/5.0',
    'Content-Type': 'application/json'
}
chunk = ["VJC", "FPT", "SSI"]
res = requests.post(url, json={"stocks": chunk}, headers=headers, timeout=5)
data = res.json().get("data", [])
for it in data:
    sym = str(it.get("stockSymbol") or "")
    match_p = float(it.get('matchedPrice') or 0.0) / 1000.0
    ref_p = float(it.get('refPrice') or 0.0) / 1000.0
    print(f"{sym}: matched={match_p}, ref={ref_p}")
