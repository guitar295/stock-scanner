import os, subprocess, urllib.request
from PIL import Image, ImageDraw

print("📦 1. Đang cài đặt thư viện Python...")
subprocess.run(["pip3", "install", "pandas", "requests", "mplfinance", "pytz", "numpy", "matplotlib", "pillow", "flask"])

base = os.path.expanduser("~/Desktop/Dashboard_mac")
os.makedirs(base + "/static", exist_ok=True)
os.makedirs(base + "/data/trade-journal", exist_ok=True)

print("🌐 2. Đang kiểm tra thư viện biểu đồ Lightweight Charts...")
lwc = base + "/static/lightweight-charts.min.js"
if not os.path.exists(lwc):
    try:
        urllib.request.urlretrieve("https://unpkg.com/lightweight-charts@4.2.3/dist/lightweight-charts.standalone.production.js", lwc)
    except Exception:
        pass

print("🚀 3. Đang tạo ứng dụng Scanner Dashboard.app...")
subprocess.run(["rm", "-rf", f"{base}/Scanner Dashboard.app"])
applescript_start = """on run
    set projDir to (POSIX path of (path to home folder)) & \"Desktop/Dashboard_mac\"
    do shell script \"cd \" & quoted form of projDir & \" && if ! pgrep -if \\\"scanner_full.py\\\" > /dev/null; then (/Library/Developer/CommandLineTools/usr/bin/python3 -u scanner_full.py < /dev/null > scanner.log 2>&1 &); for i in {1..30}; do if curl -s -f http://localhost:8888/ >/dev/null 2>&1; then break; fi; sleep 0.4; done; fi; afplay /System/Library/Sounds/Glass.aiff & osascript -e \\x27display notification \\\"Bot và Dashboard đã BẬT thành công!\\\" with title \\\"Scanner Bot\\\"\\x27\"
    try
        tell application \"Safari\"
            activate
            set tabFound to false
            if (count of windows) > 0 then
                repeat with w in windows
                    repeat with t in tabs of w
                        if URL of t contains \"localhost:8888\" or URL of t contains \"127.0.0.1:8888\" then
                            set current tab of w to t
                            set URL of t to \"http://localhost:8888/?r=\" & (do shell script \"date +%s\")
                            set tabFound to true
                            exit repeat
                        end if
                    end repeat
                    if tabFound then exit repeat
                end repeat
            end if
            if not tabFound then
                open location \"http://localhost:8888\"
            end if
        end tell
    on error
        do shell script \"open -a Safari http://localhost:8888\"
    end try
end run"""
subprocess.run(["osacompile", "-o", f"{base}/Scanner Dashboard.app", "-e", applescript_start])

print("🛑 4. Đang tạo ứng dụng Stop Scanner.app...")
subprocess.run(["rm", "-rf", f"{base}/Stop Scanner.app"])
applescript_stop = """on run
    do shell script \"pkill -if \\\"scanner_full.py\\\" 2>/dev/null || true; lsof -ti:8888 | xargs kill -9 2>/dev/null || true; afplay /System/Library/Sounds/Glass.aiff & osascript -e \\x27display notification \\\"Bot và Dashboard đã tắt hoàn toàn!\\\" with title \\\"Scanner Bot\\\"\\x27\"
end run"""
subprocess.run(["osacompile", "-o", f"{base}/Stop Scanner.app", "-e", applescript_stop])

def make_icns(img_in, icns_path):
    iconset = icns_path.replace(".icns", ".iconset")
    os.makedirs(iconset, exist_ok=True)
    for s in [16, 32, 64, 128, 256, 512, 1024]:
        if s <= 512: img_in.resize((s, s), Image.LANCZOS).save(iconset + "/icon_" + str(s) + "x" + str(s) + ".png")
        if s >= 32: img_in.resize((s, s), Image.LANCZOS).save(iconset + "/icon_" + str(s//2) + "x" + str(s//2) + "@2x.png")
    subprocess.run(["iconutil", "-c", "icns", iconset, "-o", icns_path])
    subprocess.run(["rm", "-rf", iconset])

web_icon = f"{base}/static/icon-512.png"
if not os.path.exists(web_icon): web_icon = f"{base}/static/apple-touch-icon.png"
if os.path.exists(web_icon):
    img_web = Image.open(web_icon).convert("RGBA")
    make_icns(img_web, f"{base}/Scanner Dashboard.app/Contents/Resources/applet.icns")
    subprocess.run(["rm", "-f", f"{base}/Scanner Dashboard.app/Contents/Resources/Assets.car"])

img_stop = Image.new("RGBA", (1024, 1024), (0, 0, 0, 0))
draw_stop = ImageDraw.Draw(img_stop)
draw_stop.rounded_rectangle([64, 64, 960, 960], radius=200, fill="#1e1b4b", outline="#ef4444", width=20)
draw_stop.regular_polygon((512, 512, 340), n_sides=8, rotation=22.5, fill="#dc2626", outline="#fca5a5")
draw_stop.rounded_rectangle([380, 380, 644, 644], radius=30, fill="#ffffff")
make_icns(img_stop, f"{base}/Stop Scanner.app/Contents/Resources/applet.icns")
subprocess.run(["rm", "-f", f"{base}/Stop Scanner.app/Contents/Resources/Assets.car"])

print("\n🎉🎉🎉 CÀI ĐẶT MÔI TRƯỜNG MAC BAN ĐẦU HOÀN TẤT 100%!")
print("👉 Hãy vào thư mục Desktop/Dashboard_mac và kéo 2 icon App vào thanh Dock để sử dụng!")
